# PRD — Banking Control Assurance

> Status: Approved in the planning conversation; persisted 2026-10-08.
> One-line pitch: Help an Indian bank's IT compliance reviewer trace a regulatory requirement to its controls, evidence, gaps, and proposed fixes.
> Scope reference: [D01–D06](../decisions/gov-decision-log.md).

## 1. The problem

The hackathon brief asks for an agentic system that understands banking regulations, tracks changes, assesses internal controls, identifies gaps, and suggests remedies. Its central requirement is a continuously evolving, traceable relationship:

**Regulations → obligations → applicability → policies/controls → evidence → testing → gaps → remediation → monitoring.**

A reviewer needs to see the chain, not just the final sentence. When a finding says a requirement is supported, the supporting passage and its document version must be available for inspection. When evidence is missing, the system must say what it could not establish.

This is the problem framing supplied by the brief. Claims about market size, customer demand, or time savings have not been validated.

## 2. Who this is for

- **Primary user:** An IT compliance analyst at an Indian commercial bank.
- **Their task:** Investigate whether the bank's documented controls and supplied evidence address selected applicable requirements.
- **Reviewer:** A human decides whether to accept, disagree with, or request more evidence for each finding.
- **First-release institution:** One bank profile per case, focused on a domestic commercial-bank scenario.
- **User-research boundary:** The actual incumbent workflow and measurable time savings have not been observed. Document comparison and evidence collection are the workflow we intend to support, not validated research findings.

A single authenticated operator may perform the review in the demo. We do not claim independent two-person approval.

## 3. What the first release must do

These are the eight selected features from the organiser's list. Each has a stable requirement ID and a demonstrable acceptance case.

| Requirement | Brief feature | Required behaviour | Acceptance case |
|---|---|---|---|
| REQ-F01 | 1. Regulatory intelligence and knowledge ingestion | Load a regulatory document, preserve its source/version, and expose readable extracted text and locations. | AC-F01: A reviewer can open an ingested clause and resolve it to its source. |
| REQ-F02 | 2. Regulatory change intelligence | Compare two identified versions and show changed obligations and affected control mappings. | AC-F02: A changed requirement triggers a new assessment snapshot; the old assessment remains inspectable. |
| REQ-F03 | 3. Regulatory obligation extraction | Extract specific requirements and their stated applicability with clause references. | AC-F03: Extracted requirements preserve conditions, exceptions, and the source scope. |
| REQ-F04 | 4. Bank control-framework understanding | Extract the bank's stated control, purpose, and any explicitly documented owner/frequency. | AC-F04: Missing fields remain unknown; the model does not invent them. |
| REQ-F05 | 5. Regulatory-to-control mapping | Relate applicable requirements to relevant controls, with reasons and source references. | AC-F05: A plausible but unrelated control is not treated as sufficient coverage. |
| REQ-F06 | 7. Evidence-based compliance assessment | Assess the supplied evidence against the requirement and preserve uncertainty. | AC-F06: A written policy alone cannot prove that an operational control ran. |
| REQ-F07 | 8. Gap identification | Identify supported control gaps and evidence gaps, distinguishing their meaning. | AC-F07: Missing records produce an evidence gap/needs-review finding, not an invented operational failure. |
| REQ-F08 | 10. Remediation recommendation engine | Suggest a fix or evidence request linked to the obligation and finding. | AC-F08: A reviewer can trace the proposal to the gap and approve or disagree without changing the original finding. |

Supporting requirements make that workflow usable and safe:

| Requirement | Behaviour | Acceptance case |
|---|---|---|
| REQ-X01 | Bounded agent tools and run budgets | AC-X01: Disallowed actions and exhausted budgets stop safely. |
| REQ-X02 | Case ownership and India-only private processing | AC-X02: Cross-case access is denied; cloud routing is checked before private uploads. |
| REQ-X03 | Immutable snapshots and valid citations | AC-X03: A document replacement cannot alter an in-flight assessment. |
| REQ-X04 | Durable asynchronous jobs | AC-X04: Retries do not create a second active run or a second finalized report. |
| REQ-X05 | Reviewable UI and export | AC-X05: Citation inspection, review decisions, and export preserve the evidence chain. |
| REQ-X06 | Local/cloud separation and evidence-labelled verification | AC-X06: Default checks run without AWS credentials; simulated results are visibly labelled. |

### The evidence vocabulary

“Supported” means the supplied evidence supports the scoped requirement. It is not a certification of the bank or proof obtained by inspecting live systems.

Use **supported**, **partial**, **gap**, **needs_review**, or **not_applicable** for findings. Add an evidence condition—sufficient, partial, missing, or conflicting—so the reason is clear. “Not applicable” requires a source-backed applicability reason, not merely a lack of evidence.

A **control gap** is an evidenced shortfall against a requirement. An **evidence gap** means the information needed to assess it is absent or inadequate. Reviewer disposition is a separate record.

**ELI10:** “The bank says it checks access every quarter” and “here is the completed quarterly review” answer different questions.

### Input boundaries

Use real, versioned public regulatory sources with clearly fictional bank documents for the demo. Support authorized user uploads through the same workflow. Never present fictional controls or records as real bank evidence.

The approved limits are 10 documents per case, 10 MB per file, 100 extracted document pages, and up to 20 selected obligations per assessment. The [security specification](../security/03_SECURITY_ACCESS.md) defines rejection and scope handling.

### Should have after the first release

Measure reviewer effort using an observed workflow baseline, improve search from evaluation failures, and expand the evidence corpus deliberately. These are future opportunities, not submission requirements.

### Later

OCR and multimodal interpretation, other jurisdictions and bank categories, independent reviewer-role separation, managed vector retrieval, live regulatory crawling, and changes to actual bank systems are deferred.

The other listed hackathon features—control effectiveness assessment as a distinct demonstrated capability, risk prioritization, autonomous impact analysis, what-if simulation, cross-regulation intelligence, and contradiction detection—are not separately claimed in this first-release feature count.

## 4. What success means

| Metric | Target | Measurement |
|---|---|---|
| Feature coverage | All eight selected features demonstrated | Evidence links for AC-F01–AC-F08 |
| Assessment agreement | At least 90% on at least 20 held-out labelled cases | Expected-versus-observed outcomes and per-status confusion matrix |
| Citation validity | 100% of reported citations resolve to the intended snapshot passage | Mechanical resolution plus contextual support review |
| Critical evidence failures | Zero false supported findings on designated missing/conflicting/adversarial cases | Explicit critical-case results |
| Software correctness | All applicable P0 local acceptance checks pass; no unexplained skips | [Local test plan](../testing/spec-local-test-plan.md) |
| Cloud readiness | Private routing, permissions, storage, jobs, and identity checked live | Guided deployment evidence |
| Submission | Working demo plus detailed structural architecture | Rehearsed submission package |

The numerical quality gates are our approved thresholds. The brief does not prescribe them, and passing a small benchmark does not establish general regulatory accuracy. The final F/D claim must follow the observed results.

## 5. Where this could go

If the first version works, a reviewer could carry the same evidence chain forward each time a rule or bank document changes. The useful long-term asset is a history of what was assessed, against which requirement, using which evidence, and with whose review.

That is a product direction. Continuous live monitoring, broad regulatory coverage, and enterprise readiness remain future work.

## 6. App flow

1. Sign in and create a bank case, or load the labelled fictional example.
2. Load regulation versions, policies/controls, and supporting evidence.
3. Inspect extraction results and select the applicable obligations.
4. Start the assessment and watch bounded stage/tool progress.
5. Open a finding and inspect its mapped control and cited source passages.
6. Agree, disagree, or request more evidence; preserve the reviewer note separately.
7. Introduce another regulatory version and compare its obligations and affected controls.
8. Export findings, citations, and reviewer decisions as Markdown or JSON.

## Source and provenance

Source: [ET AI Hackathon detailed problem statements](../../../hackthon_data/6ab20c4818adf_et_hackathon_detailed_problem_statements_branded.pdf), 14 pages. The common solution grid and submission rules are on pages 2–4; Problem 1 is on pages 5–6.

Source PDF SHA-256: **51C4E3C7CFECE1E7F52EED3A1F81918FFC95625A59E77AA31CA37FC4B23A3483**.

The brief defines F1/F2/F3 as at least 3/6/8 listed features. D1 is mostly structured/textual input with acceptable results in a majority of situations; D2 requires demonstrably high reliability on similar inputs; D3 adds heterogeneous multimodal input. The brief asks for a working demo and detailed structural architecture and warns against inaccurate self-estimation.

## Open verification

The precise submission cutoff, runtime package versions, AWS account/model access, regulatory corpus, and actual evaluation results are not yet verified. See [D15](../decisions/gov-decision-log.md). These unknowns must not be presented as completed work.

[Next: Technical blueprint](../architecture/02_TECHNICAL_BLUEPRINT.md)
