# Security & Access — make the boundaries visible

> Status: Approved in the planning conversation; persisted 2026-10-08.
> Depends on: [Technical Blueprint](../architecture/02_TECHNICAL_BLUEPRINT.md).
> Decisions: [D05, D09, and D10](../decisions/gov-decision-log.md).
> Verification: Requirements only; no deployed security controls have been tested.

A useful assessment needs access to documents. That access must stay narrow enough that a bad document or a convincing model response cannot grant itself more authority.

## 1. Authentication

Use Cognito authorization-code sign-in with PKCE. PKCE ties the browser's sign-in request to the code exchange. Keep access tokens in browser memory; disable public sign-up for the demo.

The API validates authentication and derives the user identity from the verified token. It must not trust an owner_id supplied in a request body.

Local development uses an explicit development identity. It must be restricted to local mode and loopback use. A cloud deployment with that bypass enabled must fail its configuration check.

**ELI10:** The app checks who you are at the door, then checks whether each document actually belongs to your case.

## 2. Roles and permissions

| Role | Can do | Cannot do |
|---|---|---|
| Authenticated operator | Create own cases; upload authorized documents; run assessments; inspect sources; record review decisions; export own reports | Read another operator's cases; alter historical source versions; grant the agent extra tools |
| Unauthenticated visitor | Load public application assets and reach sign-in | Read cases, job states, evidence, or reports |
| Deployment administrator | Configure infrastructure through AWS tools with reviewed permissions | Bypass application ownership as a normal user; expose private content through public frontend assets |

The first release allows the same operator to review their own assessment. Record human involvement accurately; do not describe this as independent four-eyes approval.

## 3. Data access and region rules

| Data | Read/write rule |
|---|---|
| Cases and bank profiles | Authenticated owner only |
| Document originals and extracted passages | Owner-authorized access; private storage; selected version required |
| Jobs, snapshots, and findings | Owner-scoped API; worker identity restricted to required resources |
| Review decisions | Authorized case owner; original AI findings remain intact |
| Exports | Generated from an authorized snapshot; retain source/version references |
| Public frontend assets | May be served through CloudFront; no private documents or report content included |

Store private documents, records, and application logs in Mumbai. The approved model profile may route within Mumbai and Hyderabad only. Verify its actual destinations and corresponding permissions before private uploads.

Use encryption in transit and at rest, block public access to the document bucket, and grant least-privilege service roles. Authorize downloads with short-lived links issued only after checking ownership. A private assessment must not be cached at a public edge.

Operational logs may record identifiers, stages, timings, error classes, and call counts. They must not contain full documents, prompts, model responses, tokens, or credentials. Do not enable raw model invocation logging by default. Review applicable service retention terms during T8.

Real bank documents never become development fixtures or tracked source files. Retention and deletion operations must be explained during deployment; no automatic deletion schedule has been approved.

## 4. Upload and extraction limits

| Limit | Approved requirement |
|---|---|
| Formats | English text PDF, DOCX, TXT, and CSV |
| Number | At most 10 documents per case |
| Individual size | At most 10 MB per file |
| Extracted page scope | At most 100 extracted document pages per case |
| Assessment scope | At most 20 explicitly selected obligations |
| Unsupported inputs | Scanned/unreadable documents, encrypted files, oversized input, unsupported formats |

Validate content as well as file extensions. A successful upload is not proof of a successful extraction. Keep unvalidated inputs out of retrieval.

Never silently truncate a document or assess only the readable fragments while implying complete coverage. Explain the rejection or ask the user to provide a smaller supported source.

**Implementation detail to freeze in T2:** DOCX, TXT, and CSV do not provide reliable fixed page counts. Define and document a consistent extracted-size equivalent for those formats before claiming the aggregate page limit is enforced. Do not invent PDF page numbers for them; preserve paragraph, line, and row locations. This clarification does not relax the approved size limits.

## 5. Agent authority and budgets

- Tools read only the current case and selected snapshot, and write assessment/progress records.
- Uploaded text has no authority to override instructions or permissions.
- The agent cannot execute commands, fetch arbitrary URLs, send messages, modify real bank controls, or publish anything.
- Limit each job to 24 model requests and ten minutes of processing from worker start.
- Persist the allowance and deadline across queue redelivery and model retries.
- Count malformed responses, rejected actions, and uncertain dispatched calls against the allowance.
- Expose a stopping reason and any unchecked obligations. Never label an exhausted partial run completed.

Do not assume that a provider safety feature replaces application authorization, citation validation, or prompt-injection tests.

## 6. Assessment and review rules

An assertion in a policy is evidence of the stated policy. It does not by itself establish operational execution.

Missing evidence yields needs_review and a specific evidence request. Relevant conflicting evidence prevents a supported finding. A control gap must identify the evidenced shortfall; an evidence gap must identify what is missing. Uncertain applicability cannot be used as a shortcut to a pass.

Reviewer dispositions—agree, disagree, or request_more_evidence—are stored separately with a note, reviewer identity, and timestamp. They do not erase the original AI result or turn a proposed remedy into an action on bank systems.

## 7. Failure behaviour

| Failure | What the user sees | What the system records |
|---|---|---|
| Invalid or unsupported document | File-specific reason and a supported next step | Error category, source identifier, validation stage |
| Missing/conflicting evidence | Needs review, with the missing or conflicting evidence identified | Finding status, evidence condition, valid source references |
| Malformed AI output or false citation | Bounded retry, then a visible failure/partial result | Validation failure and remaining allowance, without raw private output |
| Model/service unavailable | Inputs preserved; explicit retry action where budget permits | Failed stage, attempt identity, consumed allowance |
| Storage unavailable | No success claim; preserve the user's entered form where feasible | Safe error category and correlation identifier |
| Rate limited | A waiting/retry message; no fabricated progress | Retry metadata and remaining job deadline |
| Duplicate message | Existing progress/result, not a second assessment | Conditional claim/finalization result |
| Unauthorized request | Access denied without exposing case contents | A minimal access-denial event |
| Job budget exhausted | Partial/failed status with unchecked work visible | Persisted counter, deadline, completed stage outputs |

Do not display raw stack traces. Preserve entered input where safe and state the next action.

## 8. Required negative checks

The local plan includes direct-object-reference attacks, altered owner fields, invalid tokens, development-bypass deployment, source injection, invented citations, missing evidence, stale versions, repeated delivery, budget exhaustion, and malformed files.

Live checks separately verify actual IAM permissions, storage privacy, Cognito, inference destinations, and service integrations. Passing local substitutes does not prove those cloud controls.

[Next: Frontend specification](../frontend/04_FRONTEND_SPEC.md)
