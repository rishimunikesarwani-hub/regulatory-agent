# Banking Control Assurance

We want a bank reviewer to follow a conclusion all the way back to its evidence. A regulation changes. Which obligation changed? Which bank control is affected? What evidence do we have, and what needs to happen next?

That is the product we are building for Problem 1 of the ET AI Hackathon.

**Current state: approved specifications saved; application implementation has not started.** AWS resources, live model quality, deployment, and application tests have not been verified.

## Start here

Read the [project handbook](docs/guide-start-here.md). It connects the five approved specifications, the decision history, and the test plans.

| Item | Decision |
|---|---|
| Submission | 10 October 2026; exact organiser cutoff not recorded |
| Internal readiness target | 9 October evening, IST |
| First domain | Indian commercial-bank IT controls |
| Hackathon target | F3/D2, conditional on demonstrated feature coverage and reliability |
| Hosting | Cloud-native AWS architecture |
| Private data processing | India only |
| Development | Local automated tests; real AWS and model checks are separate |
| Data | Clearly fictional demo documents and authorized user uploads |
| Budget | Credits available / flexible; no numerical spending ceiling confirmed |

The working description “Banking Control Assurance” is a documentation label, not a separately approved brand name.

## How we build

**Specify → write a failing test → implement → refactor → verify.**

Every material behaviour needs a requirement, an example of success or failure, and evidence that it works. A passing test with a controlled AI response proves the application followed its contract. Live evaluations tell us whether the actual model's conclusions hold up.

**ELI10:** Decide what a good answer looks like, test for it, and then build the smallest version that passes.

## Project map

- **docs/** — product, architecture, security, frontend, delivery, decisions, and verification specifications.
- **src/** — application code, once implementation starts.
- **tests/** — software correctness checks.
- **evals/** — AI quality cases and evaluation runners.
- **ops/** — infrastructure and local verification commands.
- **data/** — public source snapshots and clearly synthetic fixtures; no real bank files in version control.
- **runs/** — dated verification and evaluation records.

The [source brief](../hackthon_data/6ab20c4818adf_et_hackathon_detailed_problem_statements_branded.pdf) remains outside the application folder. See the [PRD](docs/product/01_PRD.md) for its page references and source fingerprint.

Read [AGENTS.md](AGENTS.md) before making changes. Consult [LOG.md](LOG.md) for the current handoff.
