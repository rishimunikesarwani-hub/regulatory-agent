# Frontend Spec — let the reviewer inspect the answer

> Status: Approved in the planning conversation; persisted 2026-10-08.
> Depends on: [PRD](../product/01_PRD.md) and [Security & Access](../security/03_SECURITY_ACCESS.md).
> Reference screenshots: **NONE — design risk**. The user explicitly approved the default design.
> Decisions: [D11](../decisions/gov-decision-log.md).

The reviewer should not have to trust a polished paragraph. Give them the requirement, the control, the evidence, and the proposed fix in a form they can open and challenge.

## 1. Screens and workflow

### Cases

Show the bank profile, assessment status, and latest activity. Keep a prominent Synthetic demo label on fictional cases. Provide a clear create-case or load-demo action.

An empty workspace should explain what a case contains and how to start. It must not show invented completed assessments.

### Case workspace

Use Documents, Assessment, and Regulatory Changes tabs.

- **Documents:** Upload files; choose their role; inspect extraction, version, and validation status. Explain supported formats and approved limits before upload.
- **Assessment:** Select up to 20 obligations, run the job, inspect progress, and open its findings.
- **Regulatory Changes:** Choose explicit older/newer versions, inspect changes and affected controls, and open the new assessment without losing the previous one.

Do not silently pick an arbitrary subset when the selected scope exceeds a limit.

### Finding detail

Show the sequence **requirement → mapped control → evidence → finding → proposed fix**. Opening a citation reveals its exact source passage alongside the finding, including document/version and page, paragraph, line, or row location.

A source preview should make it clear when the citation resolves but its content does not establish the claim. Keep the review controls close to the finding.

## 2. Review and agent visibility

Reviewer actions are Agree, Disagree, and Request more evidence. Record a note and show the resulting reviewer disposition separately from the original AI finding.

Show completed stages, tools used, sources inspected, and a stopping reason. Use factual events such as “Retrieved three evidence passages,” not hidden chain-of-thought or invented progress percentages.

Local controlled-model outputs must be visibly labelled Simulated. Live outputs must identify the assessment's source snapshot and run status. Never let a realistic demo dataset disguise a simulated AI run.

**Technical:** The timeline presents bounded audit events from the application.

**ELI10:** Show what the agent did and which documents it used, so the reviewer can check the work.

## 3. Visual system

| Role | Choice | Use |
|---|---|---|
| Page background | #F8FAFC | Calm workspace background |
| Surface | #FFFFFF | Panels, tables, source previews |
| Text | #0F172A | Main text and headings |
| Primary/action | #1D4ED8 | Buttons, links, active controls |
| Muted text | #475569 | Secondary metadata; verify contrast |
| Supported indicator | #166534 | Status label/icon, never colour alone |
| Review/partial indicator | #92400E | Needs-review and partial states |
| Gap/error indicator | #B91C1C | Evidenced gaps and failures |

The last four supporting status/text colours are implementation defaults consistent with the approved palette. Verify contrast in the actual UI.

Use locally available system fonts. Body text is 16 px, labels approximately 14 px, and headings follow a clear hierarchy around 20–28 px. Use an 8 px spacing rhythm and restrained 8 px corners. Prefer light borders and minimal shadow.

Buttons should describe the action: Run assessment, Compare versions, Inspect source, Save review. Associate labels with inputs and show validation next to the relevant field.

## 4. Layout and interaction

Desktop first: a readable main workspace with a side-by-side source panel. Below 768 px, use stacked cards in place of wide tables and a full-width evidence view.

Keyboard users must be able to navigate tabs, findings, source previews, and review controls. Preserve visible focus. When opening a source panel, move focus predictably and restore it on close.

Status labels include their meaning in text. Needs review is not visually interchangeable with a passed assessment.

## 5. Integrations and states

| Integration | Loading | Failure or partial state |
|---|---|---|
| Identity | Signing-in indicator | Return to sign-in without losing safe navigation context |
| Cases | Loading placeholder | Retry action; no fake case data |
| Upload/extraction | Per-file stages | Specific rejection; file remains visibly unready |
| Assessment job | Actual stage/tool events | Stopping reason, completed findings, unchecked obligations |
| Citations | Loading source passage | Visible unavailable/invalid reference; do not show a fabricated excerpt |
| Version comparison | Identified version pair and progress | Preserve previous assessment and any validated comparison output |
| Reviewer save | Pending save indicator | Keep the entered note; retry without duplicating the decision |
| Export | Generating | Explain failure; do not download a success-labelled partial artifact |

Only an authorized snapshot is exportable. Markdown and JSON exports include source references, document versions, findings, run status, limitations, and reviewer decisions. Partial exports are explicitly labelled partial.

## 6. Browser acceptance

The required flow is upload → assessment → citation inspection → review → regulatory comparison → export. Also exercise invalid upload, access denial, interrupted job, invalid citation, keyboard navigation, and a narrow viewport.

These are future acceptance checks. No browser implementation has been tested at this documentation checkpoint.

[Next: Feature tickets](../delivery/05_FEATURE_TICKETS.md)
