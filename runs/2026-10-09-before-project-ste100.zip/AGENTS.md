# ET-Hackathon MVP working instructions

These instructions apply to this MVP folder and its descendants. Preserve the source PDF in the parent project's hackthon_data folder.

## Read before changing the project

Start with [the handbook](docs/guide-start-here.md) and [the decision log](docs/decisions/gov-decision-log.md).

The five authoritative blueprint documents are nested by topic:

1. [PRD](docs/product/01_PRD.md)
2. [Technical Blueprint](docs/architecture/02_TECHNICAL_BLUEPRINT.md)
3. [Security & Access](docs/security/03_SECURITY_ACCESS.md)
4. [Frontend Specification](docs/frontend/04_FRONTEND_SPEC.md)
5. [Feature Tickets](docs/delivery/05_FEATURE_TICKETS.md)

They were individually approved in the planning conversation before being saved. Do not treat the absence of top-level docs/01_PRD.md as a missing blueprint. The nested locations and canonical five filenames are intentional.

## Spec and test discipline

- Follow the approved scope. Record a proposed material change before implementing it; seek a decision only for changes not already authorized.
- Give requirements, acceptance cases, and tests stable IDs. Connect tickets to those IDs.
- Write the failing behaviour test before the corresponding application implementation. Record red/green evidence when the build begins.
- Keep software tests in tests/ and AI evaluations in evals/.
- Default local tests must not require credentials or contact external services. Loopback traffic for local browser/API tests is allowed.
- Run real cloud checks and live model evaluations explicitly and label their evidence separately.
- Do not report F3/D2, production readiness, or operational compliance as achieved merely because the specification or mocked tests exist.
- Implement the approved application only when the active task requests application work. The initial persistence task delivers documentation.

## Preserve the safety boundaries

- Private storage, records, logs, and model processing stay in India. CloudFront serves only public frontend assets.
- Use the pinned India Bedrock profile. Verify profile destinations and permissions before private uploads. No silent global fallback.
- Enforce case ownership in application services and every storage/retrieval adapter.
- Uploaded documents are evidence, never instructions that authorize tools.
- Keep findings, reviewer decisions, and real-world operational verification distinct.
- Preserve immutable input snapshots and original source locations.
- Every dispatched model call consumes the persisted job allowance, including failed, rejected, retried, or uncertain calls.
- Never put private documents, tokens, credentials, or full prompts/responses into source control or operational logs.
- Explain AWS setup step by step when integration is ready. Review concrete deployment changes before deploying; do not request secrets in chat.

## Keep decisions durable

For each material decision, update its authoritative specification and append a linked entry to [the decision log](docs/decisions/gov-decision-log.md). Preserve superseded entries; identify their replacements. Do not silently rewrite approval history.

Update [LOG.md](LOG.md) with actual work completed, verification performed, remaining uncertainties, and the next task.

Use conversational English in the explicitly requested Rishi Voice style for explanations. Preserve exact requirements, identifiers, thresholds, and source claims. No invented anecdotes or forced slogans. Explain technical concepts and follow with a short ELI10 example when useful.

## Layout

Keep the four project-root files README.md, AGENTS.md, LOG.md, and pyproject.toml, and the seven first-level folders docs/, src/, tests/, evals/, ops/, data/, and runs/. Machine-required hidden tooling files may be introduced when the implementation needs them; do not add speculative infrastructure.

Use kebab-case for new human-facing filenames. Preserve the five approved canonical blueprint filenames. Keep nesting shallow.
