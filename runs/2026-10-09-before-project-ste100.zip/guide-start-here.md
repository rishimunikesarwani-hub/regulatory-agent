# Start here: what we are building and why

A policy can describe a sensible control. The useful question comes next: what evidence shows that the control addressed this requirement?

Our application should make that question easy to investigate. Every finding needs a visible path back to the regulation, the bank's stated control, and the evidence used in the assessment.

**Status:** The five specifications below are approved in the planning conversation and now saved. This is a documentation baseline; the product has not been built or deployed.

## Read in this order

| Read | What it helps you understand |
|---|---|
| [1. Product requirements](product/01_PRD.md) | The user, the eight features, the boundaries, and the definition of success |
| [2. Technical blueprint](architecture/02_TECHNICAL_BLUEPRINT.md) | How the application runs locally and how the same logic connects to AWS |
| [3. Security and access](security/03_SECURITY_ACCESS.md) | Who can see what, how private documents are handled, and where the agent stops |
| [4. Frontend specification](frontend/04_FRONTEND_SPEC.md) | What the reviewer sees and how they inspect or challenge a finding |
| [5. Feature tickets](delivery/05_FEATURE_TICKETS.md) | The build order, dependencies, and acceptance checks |
| [Decision history](decisions/gov-decision-log.md) | Which choices were approved, why they matter, and what remains unverified |
| [Local test plan](testing/spec-local-test-plan.md) | How we prove the software follows its specification |
| [AI evaluation plan](testing/eval-model-quality.md) | How we measure the actual model's assessment quality |

## Four things to keep separate

**Approved** means we chose a design. **Implemented** means code exists. **Verified** means a named check produced evidence. **Achieved** means the required gates passed.

At this checkpoint, the product and architecture are approved. There are no application results to call verified or achieved.

The F3/D2 goal comes from the hackathon's feature/depth framework. F3 requires at least eight listed features. D2 calls for demonstrable reliability on mostly structured and textual input. Our own numerical evaluation thresholds are additional release criteria; they are not organiser-issued thresholds.

## The cloud decision in everyday language

**Technical:** Application services depend on interfaces for document storage, records, jobs, identity, and model calls. Local and AWS adapters implement those contracts.

**ELI10:** The reasoning and rules stay the same. On your laptop they use local connections; on AWS they use the cloud connections. We test both.

AWS setup is a later, guided implementation step. The walkthrough should explain what each service does, what we are configuring, and how we know the setup worked. We do not need an AWS account to write or run the default local tests.

## How this handbook stays current

A material decision belongs in its specification and in the decision log. Give it a date, status, rationale, and links to affected requirements and tests. Preserve an old decision when a new one replaces it.

Use the [project log](../LOG.md) to resume work. Use the [repository instructions](../AGENTS.md) before editing. Each document has a “Next” link so you can keep reading without searching through folders.

**Writing treatment:** Conversational English, Rishi Voice at the skill's default 60% rawness. Explanations use a direct peer-to-peer tone; technical contracts remain literal. The technical blueprint uses ASD-STE100 writing rules under [D17](decisions/gov-decision-log.md#d17--technical-blueprint-language).

[Next: Product requirements](product/01_PRD.md)
