# Decision log — what we chose, and what that does not prove

> Persisted: 2026-10-08.
> Source of approval: the planning conversation across 7–8 October 2026.
> Exact per-answer timestamps were not captured; the date below is the persistence date, not an invented approval timestamp.

We should be able to explain why a choice is here and what would need to change before replacing it. That is the purpose of this record.

**Approved** means the user selected or accepted it. **Implementation clarification** makes an approved requirement precise without adding a product capability. **Unverified** means evidence is still needed. No entry below establishes that the application is built.

## Approved decisions

| ID | Recorded | Decision and rationale | Specification and acceptance links |
|---|---|---|---|
| D01 | 2026-10-08 | **Approved:** Work on Problem 1, banking/financial regulations. Build the traceable regulation-to-remediation workflow described in the source brief. | [PRD](../product/01_PRD.md); REQ-F01–REQ-F08 |
| D02 | 2026-10-08 | **Approved:** Target F3/D2: at least eight selected features with demonstrable reliability on mostly structured/textual input. This is a target, not an achieved score. | [PRD metrics](../product/01_PRD.md); [quality gates](../testing/eval-model-quality.md) |
| D03 | 2026-10-08 | **Approved:** Start with India IT controls for a domestic commercial-bank scenario. One bank profile per case keeps applicability and evidence scope concrete. | [PRD audience](../product/01_PRD.md); AC-F03, AC-F05 |
| D04 | 2026-10-08 | **Approved:** Support both a clearly fictional demo bank and authorized user uploads. Fictional documents must remain labelled. | [PRD inputs](../product/01_PRD.md); UT-01, BT-05 |
| D05 | 2026-10-08 | **Approved:** Private document storage and AI processing must stay within AWS India. Mumbai is the application region; the selected inference profile may use Mumbai/Hyderabad only after verification. | [Security](../security/03_SECURITY_ACCESS.md); CLOUD-01, CLOUD-02 |
| D06 | 2026-10-08 | **Approved:** Submission is 10 October 2026. The user corrected the earlier “within seven days” answer. Internal readiness targets 9 October evening IST. Exact organiser cutoff remains unverified. | [Delivery dates](../delivery/05_FEATURE_TICKETS.md) |
| D07 | 2026-10-08 | **Approved:** Design cloud-native now; teach AWS hosting/configuration step by step when the local workflow is ready. Local tests must not require AWS setup. | [Architecture](../architecture/02_TECHNICAL_BLUEPRINT.md); CT-01, CLOUD-01–CLOUD-05 |
| D08 | 2026-10-08 | **Approved:** React/TypeScript/Vite; Python/FastAPI; API Gateway/Lambda; S3; DynamoDB; SQS; Cognito; SAM. Local filesystem, SQLite, worker, and controlled-model adapters share the application contracts. | [Stack and flow](../architecture/02_TECHNICAL_BLUEPRINT.md); CT-01–CT-04 |
| D09 | 2026-10-08 | **Approved:** One bounded agent, keyword/BM25 retrieval, application-validated actions, and pinned model profile in.openai.gpt-5.6-luna. No silent global fallback or managed-vector-service addition. Quality and account access are unverified. | [Agent/model contract](../architecture/02_TECHNICAL_BLUEPRINT.md); UT-07–UT-10, CLOUD-01 |
| D10 | 2026-10-08 | **Approved:** Cognito sign-in, own-case permissions, India processing, 10 documents/case, 10 MB/file, 100 extracted pages, up to 20 obligations/run, 24 model calls, and a ten-minute job budget. One operator can review own findings; no independent dual approval is claimed. | [Security](../security/03_SECURITY_ACCESS.md); UT-02, UT-07–UT-12, CT-02–CT-04 |
| D11 | 2026-10-08 | **Approved:** Default light reviewer workspace, Cases/Documents/Assessment/Changes flows, exact source inspection, separate human review, progress events, and Markdown/JSON exports. Reference screenshots: NONE — design risk, accepted by the user. | [Frontend](../frontend/04_FRONTEND_SPEC.md); BT-01–BT-05 |
| D12 | 2026-10-08 | **Approved:** Separate nested Markdown specifications under ET-Hackathon/MVP, a start page, and durable decision history. Use conversational English in Rishi Voice with the skill's default 60% rawness; keep contracts literal. | [Handbook](../guide-start-here.md); [project instructions](../../AGENTS.md) |
| D13 | 2026-10-08 | **Approved:** At least 20 held-out cases, at least 90% assessment agreement, fully resolvable/context-checked citations, and zero false supported results on designated critical evidence/adversarial cases. These are our gates, not organiser-issued numerical thresholds. | [Evaluation plan](../testing/eval-model-quality.md); EVAL-01–EVAL-20 |
| D14 | 2026-10-08 | **Approved:** T1–T9 build order and spec → failing test → implementation → refactor → verification loop. Persist documentation first. The present implementation request executes that documentation plan; application tickets remain pending. | [Tickets](../delivery/05_FEATURE_TICKETS.md); [local checks](../testing/spec-local-test-plan.md) |

## D15 — Unverified facts and later configuration

Recorded 2026-10-08. These are not approvals or established facts.

| Open item | Current state | Resolve in |
|---|---|---|
| AWS account, permissions, model entitlement | User requested a later teaching walkthrough; account readiness was not established | T8 |
| Numerical cloud spending ceiling | User chose credits available / flexible; no amount confirmed | T8 resource/cost review |
| Actual model quality | No live evaluation has run | T9 |
| Regulatory corpus and genuine change pair | Source leads exist; the actual authoritative versioned files have not been acquired or validated in this workspace | T1 |
| Runtime/dependency versions and SDK support | Not installed or pinned for this project | T2; live confirmation T8 |
| Nonpaginated page-equivalent handling | Must be made explicit before claiming aggregate extraction limits are enforced | T2 |
| Retention, cleanup, and applicable provider terms | No automatic deletion schedule approved; review before real private uploads | T8 |
| Exact submission cutoff | User supplied the date only | Before submission; internal target remains earlier |
| Market demand and productivity improvement | No user research or measured baseline | Future discovery; do not invent claims |

## D16 — Implementation clarifications preserved in the written specs

Recorded 2026-10-08. **Status: implementation clarifications, not separately attributed user answers.**

These make the approved evidence, retry, and review requirements testable:
- A supported finding needs the required evidence elements; a policy assertion cannot prove an operational act.
- Missing/conflicting evidence, partial fulfilment, and a demonstrated gap are distinct outcomes.
- A reviewer decision does not overwrite the AI assessment.
- Each job freezes the bank profile, selected documents, extracted passages, and model/prompt versions.
- Citations use the original PDF page, DOCX paragraph/table cell, TXT line, or CSV row; every quote is checked.
- Model-call allowances are reserved before dispatch and persist through failures, retries, and uncertain outcomes.
- The ten-minute processing clock begins at worker start and does not restart on redelivery; queue wait is recorded separately.
- Completed, partial, and failed jobs must reflect whether all selected obligations were accounted for.
- Failed outputs and abstentions remain in the evaluation denominator.
- Supporting UI text/status colours and technical field names are implementation defaults, not additional user-research findings.

Affected documents: [architecture](../architecture/02_TECHNICAL_BLUEPRINT.md), [security](../security/03_SECURITY_ACCESS.md), [local tests](../testing/spec-local-test-plan.md), and [evaluation](../testing/eval-model-quality.md).

## D17 — Technical blueprint language

Recorded 2026-10-09. **Status: approved language change.**

The user requested ASD-STE100 language, then identified the technical architecture as the target document. Rewrite the [technical blueprint](../architecture/02_TECHNICAL_BLUEPRINT.md) with ASD-STE100 Issue 9 writing rules.

For the technical blueprint only, this replaces D12's Rishi Voice writing treatment. The other D12 requirements and the writing treatment of the other documents remain in effect. This change does not alter application scope, privacy rules, interfaces, identifiers, limits, quality gates, or approval history. It does not authorize application implementation or deployment.

Preserve the [original wording](../../runs/2026-10-09-technical-blueprint-before-ste100.txt). Record the language and preservation checks in the [verification record](../../runs/2026-10-09-ste100-verification.md). The rewrite does not establish independently verified compliance with the complete STE dictionary.

Affected specification: [Technical Blueprint](../architecture/02_TECHNICAL_BLUEPRINT.md). Existing requirement, test, and ticket references remain unchanged.

## How to add a decision

Append a new entry with:
1. Stable ID and recorded date.
2. Status: proposed, approved, implementation clarification, unverified, or superseded.
3. The decision and its reason.
4. Approval/source evidence, without invented timestamps.
5. Affected specification, requirement IDs, tests, and tickets.
6. Any decision it replaces.

Update the authoritative spec in the same change. Keep superseded history and link to its replacement. Minor wording improvements do not need a new product approval; changes to scope, privacy, budgets, quality gates, or external actions do.

[Next: Local test plan](../testing/spec-local-test-plan.md)
