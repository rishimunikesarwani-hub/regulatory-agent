# One-agent and multi-agent operation

Date: 2026-10-10.
Status: Design comparison and proposal. No implementation or measured comparison exists.

## Recommendation

For the requested separation of jobs, use bounded specialist agents under a master coordinator.
Keep the one-agent design as the evaluation baseline.
Do not claim better accuracy until both designs complete the same evaluation.

For the shortest path to a working submission, one agent has the stronger delivery case.
The assessment scope is small, and its main steps depend on earlier results.
Several agents introduce extra instructions, data transfers, and failure paths.

**ELI10:** Separate AI workers can have clear jobs and permissions.
They also need correct information from each other.
More workers do not guarantee a correct assessment.

## Current design and requested direction

The [current blueprint](02_TECHNICAL_BLUEPRINT.md#3-agent-and-retrieval-rules) specifies one bounded agent.
[D09](../decisions/gov-decision-log.md) records that choice.
Problem 1 permits one or more agents.
It does not require several agents.

The user requested separate agent jobs, limits, ReAct loops, a master orchestrator, streaming tools, a registry, and governance.
The [proposed operating contract](arch-multi-agent-proposal.md) defines these parts.
The proposed roles and allowances do not yet replace D09.

## Comparison table

The table contains design judgments for this project.
It does not report measured performance.

| Question | One-agent operation | Multi-agent operation | Project judgment |
| --- | --- | --- | --- |
| Who owns the work? | One agent performs all assessment judgments. | Each specialist produces one defined result. | Several agents give clearer responsibility boundaries. |
| How much context is available? | One agent can inspect all evidence permitted by the selected snapshot. | Each agent receives selected evidence and earlier results. | One agent avoids information loss during transfers. |
| Can instructions remain focused? | One instruction set must cover several tasks. | Each role has task-specific instructions. | Several agents can reduce conflicting instructions. |
| Is the result more accurate? | Earlier assumptions can affect later judgments. | Specialists can repeat the same model error. | Neither design has demonstrated higher accuracy here. |
| Is execution faster? | There is less coordination work. | Independent tasks can run together. | Most assessment stages depend on earlier stages. Speed gains remain uncertain. |
| Is operation cheaper? | There are fewer repeated instructions and transfers. | Several agents can reduce context per call but add coordination costs. | Measure model tokens and tool usage. Agent count alone cannot determine cost. |
| Are permissions safer? | Application code must restrict each action. | Application code can give each role a smaller tool set. | Separate roles help only when code enforces their boundaries. |
| Are failures easier to find? | There are fewer execution paths. | A failure can identify a specific role or transfer. | Several agents improve attribution but require more coordination tests. |
| Can one stage run again? | Saved stage results can support recovery. | Saved role results can support recovery. | Recovery depends on saved state, not agent count. |
| Is source freshness better? | The source adapter must verify current versions. | The same verification remains necessary. | Several agents do not make stale sources current. |
| Does a reviewer prove correctness? | One agent can reconsider its own result. | Another agent can inspect the same evidence. | Another model response is not independent regulatory assurance. |
| Are authentication and streaming available? | Both can operate outside the agent. | Both can operate outside the agents. | These functions do not require several agents. |
| Is it easier to deliver today? | Fewer contracts and failure paths need implementation. | More roles and transfers need implementation. | One agent has the stronger deadline case. |
| Can responsibilities change separately? | Instruction changes can affect the complete assessment. | One role can change under a versioned contract. | Several agents offer clearer change boundaries. |

## The case for one agent

The current job covers one case and at most 20 selected obligations.
One bounded agent can inspect source passages, controls, and evidence within that scope.
It can retain an exception while moving from interpretation to assessment.

Separate agents must transfer that exception correctly.
A missing condition can invalidate every later result.
Additional agents can also consume the allowance before the evidence assessment finishes.

Authentication, citation checks, saved progress, and tool permissions still belong to application code.
A single agent can use these controls.
These controls are not exclusive benefits of a multi-agent design.

## The case for several agents

Regulatory interpretation and evidence assessment have different questions and failure conditions.
The first establishes the requirement.
The second checks what the supplied records establish.
Separate instructions can keep those judgments distinct.

A mapping agent can inspect bank controls without permission to retrieve arbitrary public URLs.
A remediation agent can propose corrections without permission to change an assessment label.
Separate contracts also let us evaluate each responsibility before an end-to-end run.

These are reasons to test the design.
They are not proof that the design produces better findings.
The same model can repeat the same error across roles.

## Source evidence and its limits

Anthropic recommends adding complexity only when it improves measured results.
It distinguishes fixed workflows from agents that select actions during execution.
See [Building effective agents](https://www.anthropic.com/engineering/building-effective-agents).

Anthropic reports benefits from parallel research and separate context windows.
It also reports coordination costs and weaker suitability for tasks with many dependencies.
Its research results do not establish gains for banking control assessment.
See [the multi-agent research report](https://www.anthropic.com/engineering/multi-agent-research-system).

Our recommendation is an inference from those principles and this project's requirements.
No published performance percentage is used as our expected improvement.

## How to choose with evidence

Use the [existing evaluation plan](../testing/eval-model-quality.md).
Keep the model, source versions, bank fixtures, selected obligations, and total allowances equal.
Apply equivalent evidence and security checks to both designs.
Count coordinator calls and repair calls in the multi-agent total.

| Measure | Required comparison |
| --- | --- |
| Assessment agreement | Compare all required outcomes, including missing results and incorrect abstentions. |
| Critical errors | Check false supported findings, missed exceptions, and unresolved contradictions. |
| Citation support | Check exact references and whether their context supports the claim. |
| Completion | Compare completed scope within the same deadline and allowances. |
| Cost | Compare input tokens, output tokens, tool charges, and total cost where available. |
| Time | Compare total duration and time spent waiting for services. |
| Recovery | Compare duplicate delivery, partial failure, and retry behavior. |
| Isolation | Compare denied cross-case reads and prohibited tool requests. |

Both designs must meet the existing release gates.
These include at least 20 held-out cases and at least 90% assessment agreement.
All required citations must resolve and support their claims.
Critical cases must have zero false supported findings.

Use development cases to adjust roles and allowances before the held-out comparison.
Do not remove difficult cases from the results.
Repeat close results before claiming a reliable advantage.
If quality is equal, prefer the design with lower cost and simpler recovery.

## Next design action

Review the [role and limit proposal](arch-multi-agent-proposal.md).
If adopted, revise the controlling specifications and regenerate both architecture formats.
Keep the existing one-agent version as the comparison baseline.
Application development remains a separate task.
