# Bounded multi-agent operation

Date: 2026-10-10.
Status: Proposed operating contract. Not implemented or performance-tested.

Read the [comparison](arch-agent-operation-comparison.md) before this proposal.
The [current blueprint](02_TECHNICAL_BLUEPRINT.md) remains the approved design.

## Decision ownership

| Item | Origin and status |
| --- | --- |
| Separate jobs, limits, ReAct, master orchestrator, registry, streaming tools, governance | Requested by the user. |
| Role division, local allowances, registry fields, and transfer rules below | Proposed in this document. |
| 24 model calls, 600 seconds, 20 obligations, case isolation, India boundary | Inherited limits. |
| External regulatory API and no crawler | Inherited source design. Provider remains undecided. |
| Better accuracy or lower cost | Unverified. Requires the comparison evaluation. |

## Terms

| Term | Meaning |
| --- | --- |
| Agent | A model-driven component that selects permitted actions to complete one assigned job. |
| ReAct loop | A repeated cycle of reasoning, tool action, and observation. |
| Runtime | Application code that executes and checks agent actions. |
| Master coordinator | The agent that selects a permitted work plan and requests registered specialist jobs. |
| Orchestrator service | The coordinator and the runtime that controls its execution. |
| Registry | A versioned list of permitted agents, tools, schemas, and limits. |
| Governance | Rules for access, evidence, source versions, budgets, review, and audit records. |
| Handoff | A checked transfer of one role's result to another role. |

ReAct is the agent pattern described in the [ReAct paper](https://arxiv.org/abs/2210.03629).
React remains the browser interface library.
The two names refer to different technologies.

## Master orchestrator and authentication

The orchestrator service receives an authorized assessment job.
Cognito authenticates the operator.
API validation checks the token before application processing.
Application code checks case ownership before it creates or reads a job.

The model does not validate credentials or grant permissions.
It receives a verified identity reference and a fixed scope.
Each tool call must pass another scope and permission check.

AWS API Gateway supports token validation before the integration receives a request.
See [JWT authorizers](https://docs.aws.amazon.com/apigateway/latest/developerguide/http-api-jwt-authorizer.html).
Token validation does not replace the application's case-ownership check.

The coordinator can inspect role definitions and safe job summaries.
It can request registered roles in a permitted dependency order.
It cannot add agents, expand source scope, change permissions, or increase the total allowance.
The runtime validates its plan before dispatch.
The runtime assembles accepted results without asking the coordinator to rewrite findings.
The runtime determines completion from validated scope and saved execution state.

## Logical structure

```mermaid
flowchart TD
    U[Operator request] --> A[Cognito and API token validation]
    A --> O[Case ownership check]
    O --> J[Saved job and fixed snapshot]
    J --> R[Orchestrator runtime]
    R --> M[Master coordinator agent]
    M --> P[Validate plan and dependency order]
    P --> R
    REG[Read-only agent registry] --> R
    GOV[Governance checks] --> R
    R --> S[Registered specialist ReAct loops]
    S --> T[Tool permission and budget checks]
    T --> E[Scoped tools and evidence]
    E --> S
    S --> V[Schema and evidence validation]
    V --> F[Saved findings and human review]
    R --> EV[Saved progress events]
    T --> EV
    EV --> UI[Authorized progress interface]
```

These are logical roles.
One worker can host the coordinator and all specialist loops.
Separate agents do not require separate Lambda services or different model providers.
The approved model and region verification gates remain.

## One job per agent

Each role owns one result type.
It can use several permitted tools to produce that result.
It cannot edit another role's result.

The allowances below apply across the entire assessment.
They do not restart for each obligation, batch, or resumed execution.
Count each model invocation separately, including tool-result continuations and final-output calls.

| ID | Role | One assigned job | Result | Base call cap | Elapsed-time cap |
| --- | --- | --- | --- | ---: | ---: |
| A0 | Master coordinator | Select and supervise a permitted execution plan. | Execution plan and coordination summary. | 2 | 45 seconds |
| A1 | Change agent | Identify substantive differences between explicitly selected regulatory versions. | Cited change set. | 2 | 45 seconds |
| A2 | Obligation agent | Express selected regulatory requirements as precise obligations. | Obligation set with conditions and exceptions. | 3 | 75 seconds |
| A3 | Applicability agent | Determine whether each selected obligation applies to the case. | Applicable, inapplicable, or unresolved decisions. | 3 | 60 seconds |
| A4 | Control mapping agent | Connect applicable obligations to stated bank controls. | Mappings with cited control details and unknown fields. | 4 | 90 seconds |
| A5 | Evidence assessment agent | Classify what supplied evidence establishes for each obligation. | Findings with evidence gaps, control gaps, and uncertainty. | 5 | 120 seconds |
| A6 | Remediation agent | Propose a response to each accepted gap or evidence request. | Cited correction proposals or evidence requests. | 3 | 60 seconds |
| Reserve | Runtime allowance | Permit bounded repair or retry after a rejected or failed model response. | No separate agent. | 2 | Inside existing deadlines. |
| Total | Complete job | Complete only the selected scope. | Validated result or visible incomplete result. | 24 | 600 seconds |

The base allowances total 22 calls.
The runtime can grant one additional repair call to a role from the two-call reserve.
No role can receive more than one reserve call.
Unused allowances do not authorize more work or additional agents.

Local time limits include model time, tool time, and retries while the role is active.
Waiting for an earlier role consumes the global deadline.
The role timer does not reset on resume.
The global deadline starts when the assessment worker starts.
It includes regulatory verification, orchestration, tool work, retries, and finalization.
Stop at the first applicable limit.
Set each call timeout within the remaining time.
Do not dispatch new work after the deadline.
Late responses cannot complete an expired assessment.
Dispatched calls still count when cancellation cannot stop them.

These allocations are testable proposals, not demonstrated capacity.
They may be insufficient for 20 difficult obligations.
Use development results to revise the allocation before freezing the evaluation.
Do not silently reduce the selected scope to fit the limit.

## Dependencies and source checks

The source adapter verifies current regulatory versions before any current assessment.
Failed verification or changed selected versions stops that assessment.
The coordinator cannot override this condition.

Run A1 only for an explicit version-comparison job with both versions selected.
Skip A1 for an ordinary assessment with unchanged selected sources.
Its output cannot silently replace the assessment snapshot.

The main assessment order is A2, A3, A4, A5, then A6.
Preserve inapplicable and unresolved decisions in the final result.
Do not send unresolved applicability to a supported finding.
Do not invent a remediation task when a finding requires no action.

The first proposal runs one specialist at a time.
This keeps recovery and allowance enforcement smaller.
Multi-agent operation does not require simultaneous execution.
Parallel execution needs a separate measured benefit and coordination tests.

## ReAct loop and stop rules

Each agent uses the following loop within its assigned job:

1. Read the assigned scope and remaining allowances.
2. Select the next permitted action or propose the final result.
3. Ask the runtime to validate the action.
4. If permitted, let the tool execute.
5. Inspect the tool result as untrusted evidence.
6. Continue only if necessary work remains and limits permit another call.

The final result ends the loop only after runtime validation.
Rejected output consumes its model call.
A repair must fit within the same role and job allowances.
Repeated actions with unchanged input and no new evidence stop the loop.
Specialists cannot create child agents or call another specialist directly.

A role must select actions from observations.
A sequence of fixed prompts alone does not satisfy this ReAct contract.
The model's internal reasoning is not a required stored or streamed artifact.

The runtime must reserve each model call before dispatch.
It must save the reservation atomically, as one indivisible operation.
Failed, malformed, rejected, repeated, and uncertain dispatched calls count.
Queue redelivery cannot reset any counter or deadline.
Retries use saved stage results and execution claims.

## Registry and tool permissions

Keep the registry as versioned configuration for the first implementation.
Do not introduce an agent marketplace or dynamic agent installation.
The runtime reads the registry. Models cannot modify it.

| Registry field | Required content |
| --- | --- |
| Identity | Stable agent ID, role version, enabled state, and instruction version. |
| Job | One purpose, required inputs, output schema, and completion conditions. |
| Dependencies | Permitted earlier roles and permitted next roles. |
| Model | Approved model profile and permitted processing regions. |
| Tools | Allowed tool names, argument schemas, and data classes. |
| Limits | Call cap, time cap, retry rules, tool limits, and output limits. |
| Evidence | Required source references, uncertainty fields, and validation rules. |

The coordinator receives registry summaries and job metadata.
It does not require raw bank documents.
A1 and A2 read selected regulatory evidence.
A3 reads the bank profile and obligation sources.
A4 reads scoped controls and obligations.
A5 reads scoped evidence and its relevant requirements and controls.
A6 reads validated findings and their permitted source references.

Private text cannot pass to the external regulatory API.
Public queries must use configured fields and permitted endpoints.
The source adapter, not an agent, holds provider credentials.
Permission checks must consider both the role and the requested resource.

Tool limits remain separate from model-call limits.
Before implementation, specify maximum requests, pagination, response size, and timeout for each tool.
Specify per-call model input/output limits and a job token allowance before live evaluation.
Missing limits must block tool activation.
The provider contract and measured task size must inform these values.
The 24-call limit alone does not establish a fixed monetary cost.

## Handoff contract

Pass structured results and exact source references.
Do not pass only an agent's prose summary.
Each handoff needs these items:

- Job, case, snapshot, task, and parent-task identifiers.
- Agent, instruction, model, registry, and schema versions.
- Selected obligation IDs, source versions, passage IDs, and inspected scope.
- Explicit conditions, exceptions, unresolved questions, and validation status.
- Completed work, remaining work, and consumed allowances.

The runtime supplies verified identity and scope.
It must reject model-provided replacements for those values.
Later agents can inspect the cited passages through scoped tools.
An earlier agent's conclusion is not an authoritative source.
Relevant unresolved contradictions prevent a supported finding.

## Streaming tools and governance

Tools emit progress events while they work.
The runtime validates and saves those events in order.
Each event identifies its job, role, action, sequence, time, and status.
Emit events from actual execution, not invented model progress.

Example events include `agent_started`, `tool_started`, `tool_progress`, `tool_finished`, `output_rejected`, and `job_stopped`.
Do not stream hidden reasoning, credentials, raw prompts, or unvalidated private text.
The authorized result interface handles evidence and findings separately.

Internal event streaming can support the approved polling interface.
Polling is not browser push streaming.
If browser push streaming is required, specify and test its transport separately.
Do not claim a long-lived connection through the current request API without integration verification.

Governance checks apply before model dispatch, before tool execution, and before result publication to the case owner.
They enforce identity, role permissions, current sources, fixed snapshots, allowances, and evidence rules.
The master coordinator cannot exempt itself or another role.

Save human review decisions separately from AI findings.
An AI review does not establish independent human approval.
No agent can change bank systems, send messages, or publish reports externally.
Keep the existing India processing boundary and private logging rules.

## Required tests before implementation acceptance

These are proposed tests. None has run.
Write failing behavior tests before application code.

| Test ID | Required behavior |
| --- | --- |
| MA-01 | Reject an invalid token before agent dispatch. |
| MA-02 | Deny another case's evidence during every role and handoff. |
| MA-03 | Reject unknown agents, tools, and altered registry fields. |
| MA-04 | Deny the 25th dispatched model call across all roles and retries. |
| MA-05 | Preserve local caps and the 600-second deadline after redelivery. |
| MA-06 | Stop before assessment when source verification fails or selected versions change. |
| MA-07 | Reject a handoff that omits a required exception or changes the snapshot. |
| MA-08 | Stop repeated tool requests that produce no new evidence. |
| MA-09 | Preserve partial results and unchecked work when a role exhausts its allowance. |
| MA-10 | Keep credentials, raw private text, and hidden reasoning out of streamed events. |
| MA-11 | Prevent the coordinator from changing a validated finding or approving its own exemption. |
| MA-12 | Compare both designs on the same held-out cases and equal total limits. |

Software checks can validate fields and references.
Domain evaluations must test whether a condition or exception has lost its meaning.
Controlled model responses do not prove live assessment quality.

## Files affected if this proposal is adopted

Revise D09, the technical blueprint, security rules, frontend events, delivery tickets, tests, and evaluations.
Add the agent requirement and acceptance conditions to the PRD.
Regenerate the ArchView and Draw.io diagrams from the revised source.
Keep the current one-agent design for the evaluation comparison.
Do not describe this proposal as an implemented system.
