# AWS review of agent operation

Date: 2026-10-10.
Scope: One operator, one assessment workflow, and the proposed AWS deployment.
Status: Design audit. Runtime performance and security behavior remain unverified.

## Recommendation

Use one bounded ReAct agent with orchestration in application code.
Keep two specialists as an evaluation candidate.
Remove the AI master from the recommended design.
The current workflow has fixed dependencies and explicit limits.
Code can select the next stage without another model call.

This recommendation replaces the earlier multi-agent recommendation in this review series.
It does not claim that one agent has demonstrated better quality.
The approved one-agent blueprint remains unchanged.

**ELI10:** Use software for rules and record handling.
Use AI where evidence needs interpretation.
Add another AI role only after it solves a measured problem.

## Five material differences

| Area | One bounded agent | Two specialists | Review judgment |
| --- | --- | --- | --- |
| AWS deployment | One assessment worker can host the agent loop. | The same worker can host both loops. | Agent count does not require more AWS services. |
| IAM and identity | Code and IAM restrict operations. | Agents using the same function credentials share its AWS permissions. | Separate agent names do not create an IAM boundary. |
| Time and cost | Fewer role transfers are necessary. A large context can still be expensive. | Smaller contexts are possible. Repeated instructions and sequential handoffs can add work. | Neither design has measured latency or cost here. |
| Evidence and context | One agent can retain context across judgments. It can also retain a mistaken assumption. | Separate instructions can focus attention. Transfers can omit an exception or propagate an error. | Preserve original passages and test meaning, not only valid JSON. |
| Private information | Code must restrict case data and model input. | One specialist can exclude unnecessary private evidence. | A smaller data set can help either design. Model separation alone is insufficient. |

The two-specialist candidate has one regulatory interpretation role and one evidence assessment role.
The first establishes applicable requirements.
The second assesses controls and evidence against those requirements.
Code coordinates both roles.
Separate prompts do not require separate functions, models, or providers.

## IAM does not require a multi-user product

An AWS execution role grants the Lambda function access to AWS resources.
Agent roles are application concepts.
Two agents using that function's default credentials share the same execution role.
This is a consequence of the [Lambda execution-role model](https://docs.aws.amazon.com/lambda/latest/dg/lambda-intro-execution-role.html).

Separate functions with restricted roles can create separate AWS permission boundaries.
Do not add that infrastructure without a concrete isolation requirement.
It can also protect fixed code services without adding more AI agents.

IAM can authorize API access with signed requests and suitable AWS credentials.
It does not remove the need for a client identity mechanism.
See [IAM API authorization](https://docs.aws.amazon.com/apigateway/latest/developerguide/http-api-access-control-iam.html).

The approved browser design already uses Cognito.
One invited operator is sufficient for this product scope.
An IAM-signed client is an alternative access design, not a reason for more agents.
Do not embed permanent AWS access keys in browser code.
No tenant management, organization hierarchy, or additional reviewer account is needed for this review.

Keep case and snapshot checks even with one operator.
The same operator can assess different banks, documents, and dates.
An earlier case must not supply evidence to the next case.

## What is a risk, and what is observed?

| Concern | Current evidence | Required response |
| --- | --- | --- |
| Performance degradation | No runtime or baseline exists. No slowdown has been measured. | Measure model, retrieval, queue, tool, and total time separately. |
| Personal-data leakage or mixing | No incident has been observed. No runtime isolation tests exist. | Filter by case and snapshot. Exclude unnecessary identifiers. Test synthetic cross-case records. |
| Context manipulation | Authorized documents can contain hostile instructions. No project attack test has run. | Treat source text as evidence. Check every tool action in code. |
| Lost context | Neither design has a measured omission rate. | Test exceptions, amendments, contradictions, and source-version boundaries. |
| Agent collusion | No intentional coordinated misconduct has been observed. | Test shared mistakes and unauthorized transfers. Do not use collusion as the architecture justification. |

IAM authorizes resource operations.
It does not determine whether text inside an authorized document is a valid instruction or a correct regulatory interpretation.
Source hashes detect changes relative to saved content.
They do not establish truth, freshness, or protection from prompt injection.

Do not retain case documents or conversation history in reusable Lambda global state.
Reuse safe service clients separately from per-job evidence.
AWS warns against retaining sensitive user data across execution-environment reuse.
See [Lambda best practices](https://docs.aws.amazon.com/lambda/latest/dg/best-practices.html).

## Use code wherever the rules are fixed

| Work | Use code for | Use the model for |
| --- | --- | --- |
| Access and governance | Identity validation, case scope, tool permissions, limits, and audit events. | No access decision. |
| Source handling | API requests, response validation, version hashes, stored snapshots, and exact text differences. | Interpret substantive changes and regulatory exceptions. |
| Retrieval and context | Parse supported text, filter sources, rank passages, remove duplicates, and enforce size limits. | Select further permitted searches when relevant evidence is missing. |
| Assessment checks | Validate schemas, IDs, source versions, exact quotations, and arithmetic. | Judge applicability, control relevance, and evidential support. |
| Workflow and output | Stage order, registry lookup, retries, deadlines, persistence, progress, and report formatting. | Propose findings and corrections grounded in evidence. |

A valid quotation does not prove that the quotation supports the conclusion.
An exact text difference does not prove that a regulatory requirement changed.
Keep those meaning checks in the assessment and evaluation process.

Use a static tool allowlist and versioned role configuration.
An AI registry manager or dynamic agent marketplace is unnecessary.
Keep the bounded ReAct loop only where evidence determines the next useful action.
Do not force every fixed processing step through a model.

## Reduce context without losing evidence

One agent does not need every document in every request.
Two agents do not need copies of each other's full conversation.
Keep canonical documents outside model context.

1. Select the case, snapshot, document versions, and obligation before retrieval.
2. Retrieve the necessary passages and their source references.
3. Include relevant conditions, definitions, exceptions, and contradictory evidence.
4. Remove duplicate passages and unrelated tool fields.
5. Exclude personal identifiers that the assessment does not require.
6. Keep a short structured record of completed work and unresolved questions.
7. Retrieve more evidence when the selected passages are insufficient.
8. Stop the current run with partial or failed status when limits prevent adequate coverage.

Preserve unchecked obligations in the result.
A smaller scope requires a new user-selected snapshot.

Do not silently remove an exception to meet a token limit.
Do not replace all source evidence with a model-written summary.
Known-field removal cannot guarantee removal of personal information from free text.
Test that boundary with synthetic identifiers and inspect residual disclosure.

## AWS latency and cost

Prompt processing depends partly on input length.
Output generation also consumes time.
Additional sequential model calls add waiting and processing work.
Their smaller inputs might offset some overhead.
AWS distinguishes prompt processing from output generation in its [latency guidance](https://docs.aws.amazon.com/bedrock/latest/userguide/monitoring-runtime-otps.html).

Separate agent loops in one worker do not create a Lambda cold start for each role.
Separate Lambda invocations introduce additional invocation boundaries and possible initialization work.
Do not add that deployment split to obtain different prompts.

Measure total duration, not only time to the first streamed event.
Streaming progress does not make the assessment finish earlier.
For sequential work, total time includes queue wait, initialization, model calls, tools, and orchestration.
Do not add overlapping spans twice if independent work runs concurrently.

Both designs can use the existing API, SQS worker, S3, DynamoDB, and Bedrock connections.
SQS and saved job state support recovery.
They do not reduce model work.
Code must handle duplicate queue delivery without restarting the allowance.
See [Lambda with SQS](https://docs.aws.amazon.com/lambda/latest/dg/with-sqs.html).

The 600-second worker budget remains below standard Lambda's documented 900-second maximum.
This does not prove that the assessment will finish in time.
Reserve finalization time and set dependency timeouts from the remaining budget.
See [Lambda timeout configuration](https://docs.aws.amazon.com/lambda/latest/dg/configuration-timeout.html).

No fixed cost estimate is justified yet.
Count all model attempts, tokens, retrieval charges, Lambda duration, storage, requests, and telemetry in the declared cost scope.
Use rates for the actual verified model, API, and regions.
Do not assume that Lambda is the main cost or that Bedrock is the main cost before measurement.

Prompt caching is optional.
Verify model, API, region, cache limits, and observed hits before counting savings.
Caching does not establish regulatory freshness or case authorization.
See [Bedrock prompt caching](https://docs.aws.amazon.com/bedrock/latest/userguide/prompt-caching.html).

## Smallest useful comparison

Build the one-agent path first with the same output contracts needed by the two-specialist candidate.
Use fixed-code orchestration for both paths.
Keep the source adapter, retrieval rules, model, regions, and validation checks equal.

Use the existing 20 held-out cases after development tuning.
Keep the 24-call job ceiling, 600-second processing deadline, and selected obligation limit equal.
Define the same aggregate token ceiling before the comparison.
The existing call ceiling is not a token or monetary budget.

Compare correct assessments, critical false supported findings, citation support, completion, total time, and total cost.
Include failures, retries, incorrect abstentions, and incomplete results.
Retain the existing 90% agreement gate and all critical evidence gates.
Do not treat 20 cases as a reliable production tail-latency estimate.

Measure each model attempt in application records.
The Bedrock Invocations metric excludes throttled requests and requests rejected before processing.
They cannot replace the application's stricter 24-dispatch counter.
Use applicable [Bedrock runtime metrics](https://docs.aws.amazon.com/bedrock/latest/userguide/monitoring-runtime-metrics.html) as supporting telemetry.

The 600-second deadline starts at worker execution.
Report queue wait separately and also include it in user-visible completion time.
No end-to-end percentile target has approval.

Adopt two specialists only if they resolve a named quality or data-exposure problem within the common limits.
If quality is equal, prefer lower cost and simpler recovery.
Retain the one-agent path when the candidate fails a critical gate.

## Review evidence

The source, test, and evaluation folders contain only placeholder files.
No application runtime, traces, or measured comparison was available.
The formal audit therefore reports UNVERIFIED performance.
See [the audit output](../../runs/2026-10-10-aws-agent-review-audit/audit.md).
Language and preservation checks are in [the verification record](../../runs/2026-10-10-aws-agent-review-verification.md).
