# One-agent and multi-agent operation

Date: 2026-10-10.
Status: Revised review recommendation. No measured performance comparison exists.

## Recommendation

Use one bounded ReAct agent with orchestration in code.
Keep two specialists as an evaluation candidate.
Do not add an AI master for fixed routing, authentication, registry lookup, or budget checks.

The user clarified a single-operator scope and a preference for code wherever fixed rules suffice.
One operator does not require tenant management or several AI roles.
The full [AWS review](arch-agent-aws-review.md) explains this revision.
The approved one-agent blueprint remains unchanged.

## Five decision points

| Point | One agent with code | Two specialists with code | Selection rule |
| --- | --- | --- | --- |
| Hosting | One assessment worker and the existing AWS services. | Both specialists can share the same worker and services. | Do not create a service for each prompt. |
| Security | IAM and application code enforce access. | The same execution role does not create separate AWS permissions for each agent. | Add infrastructure isolation only for a demonstrated requirement. |
| Performance | Fewer handoffs. Unnecessary context can still increase work. | Narrower contexts can help. Extra calls and handoffs can offset that benefit. | Compare complete time and total token usage. |
| Evidence | Less information transfer. Earlier assumptions can persist. | Separate judgments. Exceptions can be lost during transfer. | Compare source-grounded assessment errors. |
| Delivery | Fewer contracts and failure paths. | More role contracts and recovery paths. | Keep one agent unless two solve a named problem. |

## Work that remains in code

Use code for authentication, case checks, retrieval filters, hashes, schemas, limits, retries, saved state, and progress events.
Use the model for regulatory interpretation, ambiguous applicability, evidence assessment, and source-grounded correction proposals.
Keep exact reference validation separate from the judgment that a reference supports a claim.

A ReAct loop selects further permitted actions from observed evidence.
It does not require a model call for every fixed processing step.

## Candidate and evidence gate

The candidate has two roles: regulatory interpretation and evidence assessment.
Fixed code coordinates both.
The [earlier seven-role proposal](arch-multi-agent-proposal.md) remains review history, not an implementation target.

Apply the same model, sources, cases, output checks, and aggregate limits to both designs.
Retain 24 dispatched model calls and 600 seconds of processing per job.
Define a shared token ceiling before a live comparison.
The existing 20-case evaluation and critical evidence gates remain.

No slowdown, privacy incident, or quality advantage has been measured.
If quality is equal, prefer lower cost and simpler recovery.

**ELI10:** More AI workers need more coordination.
Use another worker only when its result justifies that extra work.
