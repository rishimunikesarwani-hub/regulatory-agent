# Technical Blueprint: local operation and AWS operation

> Approval: The user approved the design in the planning conversation. The project first saved this document on 2026-10-08.
> Language revision: 2026-10-10.
> Required document: [PRD](../product/01_PRD.md).
> Decision references: [D07–D10, D16, D17, D20, and D24](../decisions/gov-decision-log.md).

> Evidence status: The design has approval. This project has no deployed services or verified model invocation.
> Writing reference: [ASD-STE100 Issue 9](https://www.asd-ste100.org/assets/files/ASD-STE100_ISSUE9.pdf).

## 1. Architecture

### Architecture views

Open the [AWS system view](arch-system.html) to inspect components and service boundaries.
Open the [assessment view](arch-assessment.html) to inspect source checks, evidence processing, and human review.
Both views use ArchView and show the approved design.
The application remains unimplemented.

Use Zoom to inspect a view.
Use Image to export a PNG.
Use Report to open the browser print dialog.
Select Save as PDF to save the report.
Use the navigation links to change views.

The editable sources are [system JSON](arch-system.json) and [assessment JSON](arch-assessment.json).
The external regulatory API remains part of the design.
Provider selection remains undecided.
The user excluded a crawler view.

**ELI10:** The system view shows the parts and their connections.
The assessment view shows the checks before the operator reviews a finding.

![AWS system architecture](arch-system.png)

![Assessment controls](arch-assessment.png)

### Components

Use the same application logic for local operation and AWS operation. Keep the domain rules separate from the connections to external services.

An interface specifies how application logic communicates with a service. An adapter connects that interface to a local resource or an AWS service. The interfaces cover storage, records, jobs, identity, model calls, and public regulatory retrieval.

The local adapters let developers understand the assessment logic and do tests before AWS account configuration. At deployment, AWS adapters use the same interfaces. The adapters do not create two separate products.

| Component | Approved technology | Function |
|---|---|---|
| Frontend | React and TypeScript with Vite | Gives the user a browser workspace for evidence inspection and review. |
| Backend | Python and FastAPI | Uses request and response types to check data at the assessment interface. |
| Cloud API | API Gateway and Lambda | Processes short requests from authenticated users. Assessments run separately. |
| Private document storage | S3 in Mumbai | Stores bank files, assessment evidence copies, extracted passages, and reports. It does not determine the current regulatory version. |
| Regulatory source retrieval | External retrieval API. Provider TBD. | Retrieves current public regulations and amendments with source metadata. |
| Cloud records | DynamoDB in Mumbai | Stores case metadata, job states, counters, and references. |
| Background work | SQS and Lambda worker | Runs assessments separately from API requests. Saves progress. |
| Identity | Cognito | Authenticates operators. Does not permit demo sign-up. |
| AI | Bedrock profile in.openai.gpt-5.6-luna | Uses the selected India profile. Destination, access, and quality checks remain necessary. |
| Public frontend hosting | S3 and CloudFront | Serves public static assets only. Does not cache private reports or documents. |
| Infrastructure | AWS SAM configuration in ops/ | Describes the deployment for review. |
| Local adapters | Filesystem, SQLite, local worker, controlled AI and retrieval responses | Permits default development and tests without AWS credentials. |

Framework and package versions remain uninstalled and unverified. Packaging configuration also remains unverified. T2 must select compatible versions. The package configuration must require these exact versions. T2 must record these versions. The current root manifest contains documentation metadata only.

## 2. Request and assessment flow

The steps below describe the required application behavior.

1. The authenticated user creates a case and saves a bank profile.
2. The API authorizes the upload. It completes the upload process only after validation and extraction.
3. The application refreshes public regulations through the external retrieval API. The user selects returned versions and obligations.
4. The application starts the assessment with an input snapshot that cannot change. It returns a job ID.
5. The job runner calls the same worker service locally or through SQS.
6. The worker verifies that selected regulatory versions remain current. If selected versions changed, it requests selection review before assessment.
   After verification, it retrieves obligations and controls. Then it runs the bounded agent.
7. The agent selects permitted actions. Application code checks each action before execution.
8. The worker checks results and citations before it saves immutable findings, recommendations, and audit references.
9. The UI polls saved job progress. It shows findings, source passages, and reviewer actions. Each saved final review creates an event.
10. A later version comparison creates new results with links to the old snapshot. It does not change previous results.

Do not keep the browser request open until the assessment finishes.

API Gateway HTTP integrations have a documented integration limit of 30 seconds. The application uses jobs and does not depend on this time window. See [AWS HTTP API quotas](https://docs.aws.amazon.com/apigateway/latest/developerguide/http-api-quotas.html).

### Current regulatory sources

The external retrieval API supplies current regulatory content.
S3 stores evidence of past assessments.
Do not use an S3 copy to establish that a regulation is current.

Refresh the scoped source catalogue before obligation selection.
Revalidate selected regulations at worker start before assessment.
Use the existing job service for these network operations.
Keep the ten-minute processing deadline.

The provider must return authoritative source text and source URLs.
It must identify applicable amendments, replacements, and withdrawals.
A search snippet or provider retrieval timestamp alone cannot prove current coverage.
Record the authority verification time and provider coverage limitations.

Use publication dates and effective dates separately.
Assess applicability for the selected assessment date.
An amendment with a future effective date does not automatically replace the currently applicable requirement.

Save the exact response text and citation locations as assessment evidence.
Keep its authority, source URL, version, content hash, and amendment references.
Record retrieval time, authority verification time, and freshness status.
A freshness status states whether current-source verification succeeded for this run.
It does not promise that no later update exists.

When available, use provider version identifiers or HTTP validators.
An ETag identifies a particular HTTP representation.
Validate it against the authority or a provider with verified authority synchronization.
See [HTTP response validation](https://www.rfc-editor.org/rfc/rfc9111.html#section-4.3).

When source content or applicable regulatory metadata changes, create a new version.
Include withdrawals and effective-date changes in that comparison.
Keep the earlier assessment and its source copy.
If selected versions changed, require selection review.
Do not change the selected obligation scope automatically.

If verification fails, block a new current assessment.
Show the last successful check and the failure.
Keep historical reports accessible with their original assessment date and freshness status.
Do not silently use old content or mark it current.

T1 must select and verify the provider.
Its API endpoint, authority coverage, update delay, historical versions, terms, and pricing remain TBD.
The project has not verified a direct RBI API or a zero-delay update guarantee.

T2 must define retrieval request and response schemas.
Set request limits, timeouts, pagination limits, and response-size limits before implementation.
Count retries against the saved retrieval allowance.
Keep retrieval counters separate from the 24 model calls.
All requests must fit within the existing job deadline and document limits.
Incomplete pagination or exhausted allowances cannot establish current coverage.

The first release refreshes on request and before each current assessment.

Controlled local tests and held-out model evaluations use fixed source versions.
Label these runs as simulations or historical benchmarks.
They cannot establish current regulatory coverage.

An independent scheduled monitor remains future work.

The regulator remains the authority.
The provider transports and retrieves its content.
See [RBI Master Directions](https://www.rbi.org.in/Scripts/BS_ViewMasterDirections.aspx?did=338).

## 3. Agent and retrieval rules

Use one bounded agent. A bounded agent can use only the tools, data, and allowances that the application permits.

Keep tool execution under application control. Do not require a multi-agent framework for this release. Do not require native tool execution on the model provider's server.

The model returns a structured action request. Before tool execution, application code checks these items:

- Action name.
- Case and snapshot scope.
- Arguments.
- Remaining allowance.
- Response schema.

The agent can request only these actions:

- Retrieve obligations from the selected regulatory version.
- Find possible controls in the selected case documents.
- Inspect specified evidence passages.
- If the evidence is insufficient, request another retrieval pass within the permitted limits.
- Propose structured findings, remediation requests, and evidence requests.

Use keyword/BM25 retrieval to search selected bank documents and verified regulatory response passages. Before the relevance ranking, filter passages by owner, case, document kind, and selected version.

If retrieval did not return a passage, do not count that passage as inspected evidence. This rule also applies to relevant passages.

Measure retrieval errors separately from assessment errors.

Use the [measurement contract](../testing/spec-measurement-contract.md) for separate retrieval and assessment evaluations under REQ-X09 and AC-X09.
Measure provider source coverage, regulatory passage retrieval, and bank-evidence retrieval separately.
Use human-labelled source spans for retrieval tests.
Runtime source checks and valid citations cannot establish complete retrieval.
Do not report live recall without complete reference labels.

Keep orchestration, permissions, counters, stage order, and persistence in application code.
Use the agent for evidence interpretation and further permitted retrieval.
Do not add an autonomous second reviewer or automatic model routing to the baseline.

Do not treat a tool request in an uploaded document as authorization. The agent cannot do these actions:

- Run shell commands.
- Send messages.
- Access unrelated cases.
- Browse arbitrary URLs.
- Change bank systems.

Count every dispatched model request against the **24-call** allowance for the job. This includes schema failures, retries, and requests with an uncertain outcome.

Save a **ten-minute** job deadline that starts when the worker starts. Do not reset the deadline after a delivery retry. Record queue waiting time separately.

If the allowance is exhausted, keep the partial results that have source references. Keep the record of unchecked obligations.

## 4. Model and region configuration

| Configuration | Intended value | Secret? |
|---|---|---|
| APP_ENV | local or aws | No |
| AWS_REGION | ap-south-1, Mumbai | No |
| BEDROCK_MODEL_ID | in.openai.gpt-5.6-luna | No |
| ALLOWED_INFERENCE_REGIONS | ap-south-1 and ap-south-2 | No |
| MAX_MODEL_CALLS_PER_JOB | 24 | No |
| JOB_BUDGET_SECONDS | 600 | No |
| Document bucket, record table, queue, user pool | Outputs of the actual SAM deployment | Identifiers, not credentials |

Use IAM execution roles in AWS. Do not put credentials in configuration, browser code, or the repository.

AWS documentation describes Bedrock runtime support, structured outputs, and the India inference profile for the selected model. The project selected this model as an implementation dependency. This selection does not prove model quality.

Before the application accepts private uploads, complete these checks:

1. Check the installed SDK and API structure.
2. Check response processing.
3. Check the inference profile destinations.
4. Check an actual model invocation.

A regional endpoint alone does not prove that processing stays in India.

Sources:

- [AWS model card](https://docs.aws.amazon.com/bedrock/latest/userguide/model-card-openai-gpt-56-luna.html)
- [Inference profile destinations](https://docs.aws.amazon.com/bedrock/latest/userguide/inference-profiles-support.html)
- [Bedrock data retention](https://docs.aws.amazon.com/bedrock/latest/userguide/data-retention.html)

Do not claim that all model processing has zero retention. During integration, check the applicable model terms and service settings.

If the selected model cannot meet the approved boundaries or quality gate, record the problem. Propose a model change for review. Do not substitute another endpoint without an approved change.

Start measurements with the approved pinned model.
Record its configuration version and every model attempt.
Test later routing or a second reviewer only against a named observed failure.
Verify candidate regions, permissions, and tool compatibility before private use.
Keep the aggregate call allowance and deadline unchanged during those experiments.
An experiment does not authorize adoption or replace the approved baseline.

## 5. Records and evidence

The records below specify the approved data requirements. The field names are implementation guidance. They do not mean that a database exists.

| Record | Identity and contents | Required condition |
|---|---|---|
| Case | case_id, owner_id, bank profile, created_at | Check the owner before access to each child record. |
| DocumentVersion | document_version_id, case_id, source identity, kind, version label, SHA-256, storage reference, source URL, publication/effective dates | Do not change the content or extraction for this version. |
| Passage | passage_id, document_version_id, location, extracted text | Each passage identifies one original version and a source location that the user can inspect. |
| AssessmentSnapshot | snapshot_id, case_id, bank-profile copy, selected versions and obligations, prompt/model versions | Save the contents before execution. Do not change these contents. Do not automatically include later uploads. |
| Job | job_id, run_id, snapshot_id, state, stage, call count, deadline, execution claim, job_admitted_at, timestamps. Retrieval count, authority verification time, freshness status, audit references. | Permit only one active execution and one finalization. Keep counters through retries. |
| Obligation/Control | stable ID, structured requirement or control, applicability, source passage references | Keep unknown fields unknown. |
| Finding | finding_id, run_id, snapshot_id, obligation/control references, status, evidence condition, citations, primary recommendation, available_at | Permit at most one immutable review item per selected obligation and run. Preserve original content. Use only validated evidence. |
| ClaimEvidence | claim_id, finding_id, obligation element, claim reference, passage references, evidence period, reason reference, considered exceptions and conflicts | Preserve claim-to-source links. A valid quote alone does not establish contextual support. |
| ReviewDecision | event_id, finding_id, reviewer_id, event_kind, disposition, content references, committed_at, revision, idempotency key | Append each saved event. Preserve notes, edited content, and reasons in authorized storage. Do not overwrite earlier events or original content. |
| StageAttempt | run_id, job_id, snapshot_id, stage_id, attempt_id, state, timestamps, version references, measurements, artifact references | Preserve attempt identity and outcome. Record missing usage fields as unknown. |

Keep large extracted content and reports in private blob storage. Use the record store for metadata and references. Do not use it for report bodies of unlimited size.

Keep these original source locations:

- PDF: the original page number and a stable passage ID.
- DOCX: the paragraph or table-cell location from extraction.
- TXT: the line range.
- CSV: the row and the applicable column identifiers.

Include these items in every citation:

- Selected document version.
- Passage ID.
- Source location.
- Quoted excerpt.

Check that the stored extraction contains the quote. Check that the quote, in its context, supports the related claim.

A replacement document creates a new version. Existing snapshots continue to use the old version. Each new run must explicitly select its versions. Do not let retrieval automatically mix current and superseded files.

### Reviewer outcomes

REQ-X07 and AC-X07 require the reviewer outcomes defined in the [measurement contract](../testing/spec-measurement-contract.md#1-product-metric-and-review-unit).
Each finding and its primary recommendation form one review item.
Supporting observations do not create additional counted items.
Do not create findings for unchecked obligations merely to populate a report.

Use approved, edited, or rejected for saved final outcomes.
Use final_review and evidence_request event kinds. Only final_review carries a final disposition.
Approved always means acceptance of the original AI item.
Acceptance of an existing edited revision remains edited.
After an edit, approved requires the reviewer to explicitly return to the original item.

An edited outcome requires actual changed content and a nonblank reason.
Normalize outer whitespace and line endings before comparing edited content with the original item.
A rejected outcome requires a nonblank reason.

A comment, unsaved draft, or request for more evidence does not establish a final outcome.
Keep a previous final outcome active while a revision remains an unsaved draft.
A later evidence request does not erase an existing final outcome.

Derive reports from the latest saved final event for each eligible finding_id at the report cutoff.
Use server commit time for the cutoff and a strictly increasing per-item revision to order committed events.
Save against the expected current revision. Reject stale writes and preserve the client draft.

Deduplicate repeated requests before appending an event.
Review revisions cannot create extra counted items.
Do not carry reviews into a new run automatically.

Record cohort filters, time zone, start time, exclusive end time, and report cutoff.
Record metric_definition_version as d24-v1.
Store timestamps in UTC.

Include valid review items from partial jobs.
Use recommendation available_at for review cohorts and job_admitted_at for run cohorts.
Include admitted failed jobs without review items in result coverage and runtime measures.
Show counts, denominators, review coverage, failed jobs, partial jobs, and unchecked obligations.
Use the contract's formulas and zero-denominator rules.

Reviewer acceptance does not establish regulatory correctness.
Keep the same-operator review caveat visible.

### Stage traces

REQ-X08 and AC-X08 require the [runtime trace contract](../testing/spec-measurement-contract.md#4-runtime-traces-and-cost).
Trace source verification, extraction, retrieval, context selection, model calls, validation, persistence, and review events.
Use run_id, job_id, snapshot_id, stage_id, and attempt_id to connect records.
Record started attempts and their final, unknown, or interrupted states.
When a stage reuses an artifact, record skipped or not_applicable and its original processing reference.

Record candidate and selected passage IDs, algorithm versions, model configuration, prompt version, schema version, and application version.
Record numeric usage, durations, attempts, safe error categories, and cost evidence when available.

Missing usage or cost fields remain unknown.
Deduplicate logical charges and sum only compatible currency and cost scopes.
For the same charge, an authoritative bill replaces its estimate at the report cutoff.
Separate queue wait, worker time, stage time, and reviewer delay.
Do not add overlapping durations as wall-clock time.

Keep source text, query text, review edits, and review reasons in authorized case evidence storage.
Operational logs contain controlled identifiers, numeric measurements, and safe error categories only.
Numeric model-token counts are permitted.
Authentication tokens, private text, and hidden model reasoning are prohibited in operational logs.
Keep all private records and logs in Mumbai under the security specification.

## 6. API functions

The first API requires authentication for the functions below.

| Function | Required input and output behavior |
|---|---|
| Create/list/read case | Restrict the bank profile and case metadata to the owner. |
| Authorize/finalize upload | Connect the upload to the case. Return validation and extraction results before the document becomes eligible for analysis. |
| List/read document sources | Return version metadata. Permit passage inspection only after authorization. |
| Refresh regulations | Retrieve the configured public source scope through the external API. Return version metadata and freshness results through a job. |
| Start assessment | Accept selected versions, obligations, and an idempotency key. Return the job ID promptly. Revalidate current sources before assessment. |
| Start regulatory comparison | Require explicit older and newer regulatory versions and the affected assessment context. |
| Read job | Return the stage, terminal state, progress, allowance, and stop information. |
| Read findings | Return evidence, limitations, and proposed remedies for the specified snapshot. |
| Save review decision | Validate the outcome, accepted content, reason, and idempotency key. Approved must accept the original item. Append the event separately. |
| Read reviewer outcomes | Return cohort filters, cutoff, counts, denominators, and coverage under the measurement contract. Enforce case ownership. |
| Read stage trace | Return authorized controlled metadata and permitted artifact references. Keep private text outside operational telemetry. |
| Export assessment | Export Markdown or JSON. Include versions, citations, findings, review events, run status, regulatory verification time, and report cutoff. |

An idempotency key identifies repeated requests for the same operation.

In T2, set the executable request and response schemas before development of the handlers. Also set the related contract tests before development of the handlers.

D20 adds regulatory refresh and current-source verification to the approved API functions. Exact URL spellings are not additional product requirements.
D24 adds reviewer outcomes and stage traces under REQ-X07/AC-X07 and REQ-X08/AC-X08.
REQ-X09/AC-X09 defines separate evaluation behavior, not a public evaluation API.

## 7. Retries and failures

Use these job states:

| State | Meaning |
|---|---|
| queued | The job waits for execution. |
| running | The worker processes the job. |
| completed | The job accounts for every selected obligation. Required audit references and finalization data are saved. Human review can remain pending. |
| partial | The job has useful results that pass validation. Some required work remains unchecked. |
| failed | The assessment cannot produce a usable result. |

An atomic reservation completes as one indivisible operation.

Reserve the model-call allowance atomically before dispatch. If a process stops after dispatch, the reserved call still counts.

Use conditional execution claims to prevent competing assessments and duplicate finalization after duplicate queue deliveries.

Save the stage outputs. Save the identity of work that is already complete. Retry only within the remaining job allowance.

Save audit-critical stage references and finalization data before reporting success.
If that save fails, do not mark the assessment completed.
Preserve recoverable progress and show the failure.
Retry the failed save without repeating an already completed model assessment.

A failed external metric export does not require another assessment.
Record that failure safely and retry the export.
Deduplicate metric events by stable event identity.
A failed review save cannot change the reported final outcome or its counts.

If regulatory verification fails or selected versions changed, stop before assessment. Record the reason in the failed job.

Reject invalid outputs. Reject unauthorized actions. Do not use these outputs or actions as evidence.

Set infrastructure timeouts and queue retry settings to support the saved application deadline. Do not let these settings reset that deadline.

Standard SQS queues can deliver the same message more than once. See [AWS delivery semantics](https://docs.aws.amazon.com/AWSSimpleQueueService/latest/SQSDeveloperGuide/standard-queues-at-least-once-delivery.html).

## 8. Project organization and verification

Keep these folders in the project root:

- docs/
- src/
- tests/
- evals/
- ops/
- data/
- runs/

Inside src/, keep domain logic separate from HTTP handlers and provider adapters. Do not create a layers/ folder.

The [local test plan](../testing/spec-local-test-plan.md) covers domain and adapter contracts. The [AI evaluation plan](../testing/eval-model-quality.md) covers actual retrieval and model behavior.

The [measurement contract](../testing/spec-measurement-contract.md) controls reviewer metrics, retrieval scoring, stage traces, and measured improvement.
Use separate evidence for local calculation tests, live source integration, and held-out model evaluation.
Reviewer approval does not replace the existing assessment quality gates.

T8 must check the real AWS integration. T8 must also provide the configuration lesson with steps in sequence.

[Next: Security and access](../security/03_SECURITY_ACCESS.md)
