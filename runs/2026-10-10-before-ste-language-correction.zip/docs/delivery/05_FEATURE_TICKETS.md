# Feature tickets

> Status: Approved in the planning conversation. Persisted 2026-10-08.
> Depends on: [PRD](../product/01_PRD.md), [Technical Blueprint](../architecture/02_TECHNICAL_BLUEPRINT.md), [Security](../security/03_SECURITY_ACCESS.md), and [Frontend](../frontend/04_FRONTEND_SPEC.md).

> Decisions: [D12–D14](../decisions/gov-decision-log.md) and [D24](../decisions/gov-decision-log.md#d24---reviewer-outcomes-and-measured-agent-baseline).
> Measurement requirements: [Measurement contract](../testing/spec-measurement-contract.md). Approved under D24. Application measurements remain unavailable.
> Implementation state: Documentation saved. Application work and fixture acquisition remain pending.

First, assess one obligation through the complete process. Record its source, mapped control, evidence, finding, and review decision. Then extend the process.

The measurement contract controls reviewer outcomes, retrieval scores, assessment quality, traces, and cost calculations.
Keep one agent and the approved model `in.openai.gpt-5.6-luna` for the baseline.
Use code for fixed rules, access, workflow routing, retries, budgets, validation, and progress.
Keep the 24-call allowance and 600-second worker deadline.
These tickets do not establish completed tests or measured improvement.

## Priority and status

- **P0:** Required for the scoped submission.
- **P1:** Useful after the scoped release. Not on its critical path.
- **P2:** Deferred exploration.

All T1–T9 below are P0. Each ticket contains work that can be verified. Record incomplete work. Do not mark an incomplete ticket as complete.

For each implemented behavior, record its actual failing test before writing the application code.
Then record the passing result and affected regression checks.
A planned test or later passing result alone does not satisfy this sequence.

## T1 — Specifications and fixtures

**Status:** In progress: specification persistence complete. Source and fixture work not started.  
**Dependencies:** None.  
**Requirements:** All requirement IDs. Especially REQ-F01–REQ-F08, REQ-X03, and REQ-X07–REQ-X09.

Save the approved five documents, their decisions, and test/evaluation contracts. Acquire and freeze appropriate public RBI source versions and a clearly fictional bank evidence pack.

Acceptance:
- [x] Five individually approved specifications saved in their agreed nested locations.
- [x] Decision history, source-brief fingerprint, local test plan, and AI evaluation plan saved.
- [ ] Select the external regulatory retrieval provider. Verify authority coverage, update delay, versions, amendments, terms, and pricing.
- [ ] Acquire the regulatory source files. Record authority, publication/effective dates, scope, version, URL, retrieval time, and content hash.
- [ ] Verify a genuine change pair or explicitly label a constructed change as a simulation. Never present a synthetic amendment as an RBI event.
- [ ] Create a fictional bank profile, policies, controls, and planted evidence/control gaps with source-linked expected outcomes.
- [ ] Separate development examples from at least 20 held-out evaluation cases before tuning prompts.
- [ ] Label required source versions and original source spans before retrieval evaluation. Include decisive exceptions, conflicts, irrelevant passages, and missing evidence.
- [ ] Record annotation rules and domain-review status. Do not use the evaluated model as the only label authority.
- [ ] Prepare review histories covering Approved, Edited, Rejected, pending actions, revisions, duplicate requests, empty cohorts, and partial jobs.
- [ ] Prepare controlled clocks, model responses, usage records, and failures for the measurement tests.
- [x] Validate the documentation package. Link its report in LOG.md.

**Measurement checks:** UT-13–UT-18 and RET-01–RET-06 use these fixtures. The existing EVAL-01–EVAL-20 assessment cases remain required.

**Source candidates:** Planning research identified [RBI's Master Directions index](https://www.rbi.org.in/scripts/BS_ViewMasterDirections.aspx), [a current-direction candidate](https://www.rbi.org.in/scripts/BS_ViewMasDirections.aspx?id=13643), and [a historical-version candidate](https://www.rbi.org.in/scripts/NotificationPreVersion.aspx?Histid=250&id=13643). A later request for the two content pages failed. Get the source files. Verify their text, applicability, and dates before fixture use. Do not describe a 2023 document as current without verification.

## T2 — Local test environment and executable contracts

**Status:** Not started.  
**Dependencies:** T1's specifications and minimum labelled fixture.  
**Requirements:** REQ-X06–REQ-X09 and the contract surfaces for all features.

Create the minimal local developer environment. Pin compatible runtime/dependency versions. Freeze executable data/API schemas and adapter contracts before application handlers.

Acceptance:
- [ ] One documented command runs default local checks without AWS credentials or external network calls.
- [ ] Loopback browser/API tests remain permitted. External-network blocking is verified in actual worker processes.
- [ ] Filesystem, SQLite, local job runner, and controlled model adapters satisfy shared contracts.
- [ ] Define the regulatory API schema and controlled local responses. Set bounded retrieval requests, retries, timeouts, pagination, and sizes.
- [ ] Nonpaginated extracted-size/page-equivalent handling is explicitly specified and tested before upload enforcement is claimed.
- [ ] Define immutable review items, saved review events, cohort filters, cutoffs, and aggregate report schemas under the measurement contract.
- [ ] Define stage and attempt records with stable IDs, versions, status, timing, usage, and safe error fields.
- [ ] Define separate retrieval and assessment evaluation contracts. Keep controlled tests distinct from live quality measurements.
- [ ] Requirement IDs and corresponding red/green test evidence are recorded.
- [ ] Dependency/runtime locks and setup instructions work from a clean environment.

**Measurement checks:** UT-13–UT-18 and CT-06–CT-08 cover formulas, history, retrieval scoring, traces, cost, privacy, persistence, exports, and baseline configuration.
Write each behavior test before its implementation. Use the actual failing and passing records for ticket acceptance.

## T3 — Documents and traceability

**Status:** Not started.  
**Dependencies:** T2.  
**Requirements:** REQ-F01, REQ-X02, REQ-X03, REQ-X08, REQ-X09.

Implement bank-file validation, extraction, source locations, immutable versions, and selected-snapshot retrieval.
Implement regulatory API refresh and current-source verification.

Acceptance:
- [ ] PDF, DOCX, TXT, and CSV preserve their appropriate source locations.
- [ ] Invalid, encrypted, scanned, unreadable, unsupported, or oversized input is rejected clearly.
- [ ] File and aggregate limits are enforced without silent truncation.
- [ ] Citation quotes resolve to the exact selected document version.
- [ ] Refresh before selection and revalidate before assessment. Block failures and changed selections.
- [ ] Detect amendments, replacements, withdrawals, and effective-date changes. Preserve historical assessment evidence.
- [ ] The external API receives public source queries only. Enforce destination and response limits.
- [ ] Replacing a file creates a new version and does not change an existing or running assessment.
- [ ] Preserve original source spans and extraction/version records for retrieval labels, selected passages, and claim inspection.
- [ ] Connect reused artifacts to their original extraction or verification records. Record skipped or not_applicable stages explicitly.
- [ ] Keep private source text and queries in authorized India case storage. Exclude them from operational logs.

**Measurement checks:** UT-18 and CT-07 cover record integrity and safe persistence. RET-04 and RET-06 cover source boundaries and overlapping passages.

## T4 — First complete assessment slice

**Status:** Not started.  
**Dependencies:** T3.  
**Requirements:** REQ-F03–REQ-F08, REQ-X08, REQ-X09.

Use the local adapter contracts. Implement one complete sequence: obligation → control → evidence → finding → remediation.

Acceptance:
- [ ] Conditions and applicability remain attached to the extracted obligation.
- [ ] A relevant control is mapped with source references.
- [ ] Missing operational evidence cannot be replaced by a policy promise.
- [ ] Findings distinguish supported, partial, gap, needs_review, and not_applicable according to the rubric.
- [ ] Evidence gaps and evidenced control failures remain distinguishable.
- [ ] Proposed fixes and reviewer decisions are linked to the original finding.
- [ ] Apply case, snapshot, source-version, and evidence-period filters before bounded passage retrieval.
- [ ] Preserve candidate and selected passage IDs. Record query duration, attempts, passage counts, and selected text size.
- [ ] Score provider coverage, regulatory retrieval, and bank-evidence retrieval separately against labelled source spans.
- [ ] Handle duplicate spans, empty results, missing spans, unknown labels, and decisive omissions under the measurement contract.
- [ ] Retain each claim's obligation element, citations, evidence period, concise reason, and considered exceptions or conflicts.

**Measurement checks:** UT-15 and RET-01–RET-06 cover retrieval. Existing assessment tests verify meaning and evidence support separately.
An exact quote match does not prove contextual support.

## T5 — Bounded agent and regulatory changes

**Status:** Not started.  
**Dependencies:** T4.  
**Requirements:** REQ-F02–REQ-F08, REQ-X01, REQ-X03, REQ-X08, REQ-X09.

Add validated model-selected tool actions, controlled retrieval refinement, and explicit version comparisons. Expand only to the approved obligation scope.

Acceptance:
- [ ] The agent selects permitted tools through validated structured actions.
- [ ] Use one bounded agent with code orchestration and the approved pinned model. Add no automatic router or autonomous second reviewer.
- [ ] Scope filters apply before retrieval, and injected instructions cannot grant additional capabilities.
- [ ] Invalid JSON, rejected actions, and retried calls consume the same persisted call budget.
- [ ] Record every dispatched model attempt, including uncertain outcomes, against the same 24-call allowance.
- [ ] Record model configuration, prompt, schema, extraction, chunking, retrieval, and application versions. Record provider identifiers only when available.
- [ ] Trace source verification, extraction, retrieval, context selection, model calls, validation, persistence, and review events.
- [ ] End every started attempt or record an explicit unknown or interrupted status. Keep the saved 600-second worker deadline across restarts.
- [ ] A material regulatory change identifies affected obligations/controls and produces a new snapshot.
- [ ] A new assessment creates new review items. Never transfer earlier human outcomes automatically.
- [ ] Cosmetic changes do not automatically become changed obligations.
- [ ] Stale evidence, unavailable tools, budget exhaustion, and partial results follow the specification.

**Measurement checks:** UT-16, UT-18, and CT-08 verify traces, limits, and the pinned baseline.

## T6 — API, jobs, ownership, and review records

**Status:** Not started.  
**Dependencies:** T4. Shared contracts from T2.  
**Requirements:** REQ-X02–REQ-X05, REQ-X07, REQ-X08.

Implement short owner-scoped API requests and durable asynchronous execution. Keep review records separate from AI findings.

Acceptance:
- [ ] Start operations return job IDs and stable input snapshots.
- [ ] Access checks cover cases, uploads, source previews, jobs, findings, and exports.
- [ ] Duplicate requests/messages yield one active execution and one finalized result.
- [ ] Counters, deadlines, execution claims, and stage outputs survive retries/restarts.
- [ ] Partial and failed outcomes preserve attributable work and expose unchecked obligations.
- [ ] Review saves cannot overwrite the AI finding or create duplicate decisions on retry.
- [ ] Store Approved, Edited, and Rejected as final outcomes for one immutable finding and its primary recommendation.
- [ ] Require changed accepted content and a reason for Edited. Require a reason for Rejected.
- [ ] Keep unsaved drafts pending. Keep evidence requests pending until the reviewer saves a final outcome.
- [ ] Preserve review history and earlier report cutoffs. Keep a saved final outcome active while a later revision remains unsaved.
- [ ] Calculate approval without edits, edit share, rejection share, adoption including edits, review coverage, and result coverage in code.
- [ ] Use distinct review items and the latest saved outcome at the cutoff. Return null for zero-denominator rates.
- [ ] Include valid partial-job items, failed runs, and unchecked obligations under the specified denominators. Never invent findings for unchecked work.
- [ ] Calculate duration summaries and costs from controlled records. Preserve unknown values and incomplete cost coverage.
- [ ] Persist audit-critical references before success. Record metric-export failures separately. Retry export without repeating the model assessment.
- [ ] Deduplicate trace and metric events during retries and queue redelivery. Keep private review content outside operational logs.

**Measurement checks:** UT-13, UT-14, UT-17, UT-18, CT-06, and CT-07 cover reviews, aggregates, history, privacy, and recovery.

## T7 — Review interface

**Status:** Not started.  
**Dependencies:** T5 and T6.  
**Requirements:** REQ-X05–REQ-X08. AC-F01–AC-F08.

Implement the approved case workspace, source inspection, change comparison, and exports.

Acceptance:
- [ ] Browser tests cover upload → assessment → citation inspection → review → comparison → export.
- [ ] Source previews resolve to the original snapshot after a document replacement.
- [ ] Synthetic data and simulated model outputs are labelled independently.
- [ ] Loading, empty, denied, partial, and failed states are useful and truthful.
- [ ] Keyboard navigation and a viewport below 768 px work.
- [ ] Export retains versions, evidence, run status, reviewer records, and limitations.
- [ ] Show authority verification time and freshness failures. Export that metadata.
- [ ] Present Approved, Edited, and Rejected independently of AI finding status. Preserve drafts and show review history.
- [ ] Show approval without edits as the north star rate. Show edit, rejection, adoption, review coverage, and result coverage separately.
- [ ] Show counts, denominators, cohort filters, cutoff, and Not measured states. Display failed/partial jobs and unchecked obligations beside coverage.
- [ ] Separate model/prompt versions, finding statuses, reviewers, and data classes. Keep live results, controlled simulations, and offline benchmarks separate.
- [ ] Export the same authorized metric definitions, counts, filters, and limitations that the interface displays.
- [ ] Use the existing operator identity. Do not claim independent review or treat human approval as proof of regulatory correctness.

**Measurement checks:** BT-06 verifies outcomes, coverage, history, and empty states. CT-06 verifies authorized report and export consistency.

## T8 — AWS integration and Rishi's guided deployment

**Status:** Not started.  
**Dependencies:** T6 and T7. Begin connectivity checks when the local slice is stable.  
**Requirements:** REQ-X02, REQ-X04, REQ-X06, REQ-X08.

Implement the SAM configuration and AWS adapters. Validate both. Explain each service and configuration step during T8.

Acceptance:
- [ ] Validate infrastructure configuration and review the concrete resources, permissions, expected costs, and rollback/cleanup approach before deployment.
- [ ] Guide Rishi through account/role access without asking for secrets in chat.
- [ ] Verify the pinned model's account access, SDK/API shape, inference-profile destinations, and applicable retention configuration.
- [ ] Run a small live call using synthetic input before private documents.
- [ ] Verify real Cognito login, ownership, S3 privacy, records, queue processing, and worker permissions.
- [ ] Check that development identity cannot run in the cloud configuration.
- [ ] Verify live regulatory API access, authority synchronization, change detection, failure handling, and absence of private request content.
- [ ] Document the commands and observed outputs in a step-by-step deployment guide and dated run record.
- [ ] Leave private uploads disabled until the required region/access checks pass.
- [ ] Reconcile application attempts with available AWS metrics. Keep the saved dispatch counter authoritative for the 24-call allowance.
- [ ] Verify stage timing, usage availability, safe logs, metric deduplication, and audit-save recovery in AWS.
- [ ] Record missing provider usage as unknown. Do not interpret missing metrics as zero calls or zero cost.
- [ ] Separate inference cost from measured system cost. Record currency, rate source/date, Region, coverage, and estimated or billed status.

**Measurement check:** CLOUD-06 verifies the live measurement boundaries. Controlled local responses do not establish cloud behavior.

Available credits do not prove model access. They do not permit unlimited spending. Record the cost estimate and spending controls during the deployment instructions.

## T9 — Quality and submission evidence

**Status:** Not started.  
**Dependencies:** T8 and completed T1 held-out set.  
**Requirements:** All feature acceptance cases and release gates.

Run the live evaluation. Rehearse the demonstration. Document the architecture of the implemented system. Include decisions, tool actions, model use, and failure handling.

Acceptance:
- [ ] At least 20 held-out cases run with the pinned live model and recorded prompt/model versions.
- [ ] Save the one-agent baseline with `in.openai.gpt-5.6-luna` and all required configuration versions.
- [ ] Run RET-01–RET-06 separately from EVAL-01–EVAL-20. Report provider coverage, regulatory retrieval, and bank-evidence retrieval independently.
- [ ] Preserve per-query counts, source labels, selected context, decisive omissions, and aggregate numerator/denominator totals.
- [ ] Do not report unlabelled live recall as measured. Keep historical benchmark scores distinct from current-source verification.
- [ ] At least 90% expected-assessment agreement. All cases accounted for, including abstentions and errors.
- [ ] Report per-status results and a confusion matrix. Separate retrieval failures, wrong mappings, unsupported claims, citation failures, status errors, and poor remedies.
- [ ] All reported citations resolve to the intended passage, and contextual support is checked.
- [ ] Zero false supported findings in designated critical evidence/adversarial cases.
- [ ] Report reviewer outcomes separately from assessment correctness. Record same-operator review and small sample counts without significance claims.
- [ ] Report queue wait, stage/attempt timing, terminal duration, retries, failures, usage, and cost coverage from the saved traces.
- [ ] Calculate nearest-rank p50/p95 for defined comparable groups. Do not present the 600-second deadline as an end-to-end percentile target.
- [ ] Include failed and incorrect runs in cost per correct assessment. Report the ratio as undefined when no correct cases exist.
- [ ] All eight feature claims link to demonstrated behaviour and evidence.
- [ ] Remaining failures and scope limits appear in the report. The F/D claim follows actual evidence.
- [ ] Working demo, architecture, and rehearsal record are ready before submission.
- [ ] The user performs or explicitly authorizes the external submission. Preparing this package does not authorize sending it.

Keep routing and an autonomous second reviewer as later experiments after the baseline.
Require a named observed problem before a comparison.

Keep cases, source versions, permissions, and aggregate limits comparable.
Verify candidate model versions, India processing, and tool compatibility before private use.
Do not tune from held-out answers and still describe those cases as untouched.
Require existing quality gates and measured benefit before adopting a candidate.
An experiment does not automatically replace the approved baseline or enter this P0 delivery sequence.

## Build order and dates

**8 October target:** Prepare the sources, fixtures, and local environment. Implement the first complete assessment. T5 and T6 extend that assessment. T7 adds the review interface.

**9 October target:** Complete guided AWS integration and live evaluation. Correct failures. Rehearse the demonstration. Complete the architecture documents. Target completion that evening IST.

**10 October:** Submission date. The exact organiser cutoff remains unverified. These dates are targets. They do not show completed work.

Exclude P1/P2 work from this delivery sequence unless the user explicitly changes the scope. See the [PRD](../product/01_PRD.md) for deferred capabilities.

[Next: Local test plan](../testing/spec-local-test-plan.md)
