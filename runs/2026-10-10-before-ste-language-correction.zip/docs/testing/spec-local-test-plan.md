# Local test plan

> Status: Approved workflow and acceptance requirements. Measurement test plans updated 2026-10-10 under D24.
> Software tests executed so far: **none**. No application or test runner exists yet.
> Related: [tickets](../delivery/05_FEATURE_TICKETS.md), [architecture](../architecture/02_TECHNICAL_BLUEPRINT.md), [AI quality plan](eval-model-quality.md), [measurement contract](spec-measurement-contract.md).

Tests must detect errors that affect review decisions. A returned value alone does not prove correct behavior. For example, a finding can cite the wrong document version.

## 1. Development loop

For each small behaviour:
1. Name the requirement and acceptance case.
2. Write a test that fails for the intended missing behaviour.
3. Record the failure before implementing the behaviour.
4. Implement the smallest change that satisfies the contract.
5. Run the relevant test and then the affected regression checks.
6. Refactor the code. Keep the required tests passing.
7. Record results and remaining limitations in runs/ and LOG.md.

T2 must define one runnable local check command and record exact versions. No command is advertised as available before it exists.

## 2. Local boundaries

- Run domain tests with controlled inputs and explicit expected outcomes.
- Test real local filesystem/SQLite adapters through the same contracts as AWS adapters.
- Stub AWS requests/responses for adapter contract checks. Do not interpret a stub as proof of real IAM or service behaviour.
- Use controlled model responses to cover malformed output, tool selection, retries, and evidence validation.
- Use controlled regulatory API responses. Default tests must not contact the provider.
- Browser tests may contact loopback services. Default tests block external network calls and need no AWS credentials.
- Verify the network guard inside actual test workers, not merely in a parent process.
- Use fictional documents only. Private uploads are never fixtures or CI artifacts.

**Plain explanation:** Tests give the application known problems. The results show whether the application follows the rules. Live AI quality needs a separate evaluation.

## 3. Domain tests

| Test ID | Requirement / acceptance | Scenario and required result |
|---|---|---|
| UT-01 | REQ-F01 / AC-F01 | Each supported format extracts text with stable source/version IDs and usable source locations. Synthetic labels survive. |
| UT-02 | REQ-F01, REQ-X01 / AC-X01 | Unsupported, empty, corrupt, encrypted, scanned/unreadable, or oversized files are rejected. Document/page/scope limits never silently truncate. |
| UT-03 | REQ-F03 / AC-F03 | Obligation extraction retains conditions, exceptions, applicability, and citations. Absent fields are unknown. |
| UT-04 | REQ-F04, REQ-F05 / AC-F04, AC-F05 | Documented controls retain their stated scope. A merely similar control is not sufficient coverage. |
| UT-05 | REQ-F06, REQ-F07 / AC-F06, AC-F07 | Policy-only, missing, conflicting, and mixed operational evidence produce the correct distinct statuses. No unsupported pass. |
| UT-06 | REQ-F08 / AC-F08 | A proposed remedy/evidence request refers to the actual finding and obligation. No action on bank systems occurs. |
| UT-07 | REQ-X01 / AC-X01 | Untrusted document instructions and unknown tool actions cannot expand scope or execute capabilities. |
| UT-08 | REQ-X03 / AC-X03 | An invented quote, a valid passage from a different version, or a quote from another case fails validation. |
| UT-09 | REQ-X01 / AC-X01 | Invalid JSON, rejected actions, timeouts, and uncertain dispatched calls consume the persisted allowance. Call 25 cannot be dispatched. |
| UT-10 | REQ-F01, REQ-F02, REQ-X03 / AC-F01, AC-F02, AC-X03 | A substantive change selects affected obligations/controls. Cosmetic wording changes do not automatically change the obligation. Snapshots remain immutable. Amendments and withdrawals create new version metadata. |
| UT-11 | REQ-X04 / AC-X04 | Deadline exhaustion preserves completed findings and lists unchecked work. Partial/failed jobs never masquerade as completed. |
| UT-12 | REQ-X05 / AC-X05 | Human disposition is stored separately. Disagreeing never erases the original finding or source history. |
| UT-13 | REQ-X07 / AC-X07 | Outcome rates use distinct review items and the correct cohort. Pending items, partial jobs, and zero denominators retain their defined meanings. |
| UT-14 | REQ-X05, REQ-X07 / AC-X05, AC-X07 | Review revisions preserve history and original findings. Edited content and rejection reasons are required. Concurrent or repeated requests cannot increase item counts. |
| UT-15 | REQ-X09 / AC-X09 | Retrieval scores use labelled source spans and selected passages. Duplicate identities, overlapping chunks, empty results, and source classes produce the defined counts. |
| UT-16 | REQ-X01, REQ-X04, REQ-X08 / AC-X01, AC-X04, AC-X08 | Stage traces preserve timers, attempt states, and limits. Retries and restarts cannot reset the 24-call allowance or 600-second worker deadline. |
| UT-17 | REQ-X08, REQ-X09 / AC-X08, AC-X09 | Usage, cost, and percentile calculations preserve missing values. Cost per correct assessment includes failed and incorrect cases. |
| UT-18 | REQ-X02, REQ-X03, REQ-X08 / AC-X02, AC-X03, AC-X08 | Operational telemetry excludes private content. Interrupted attempts retain explicit states. Success requires saved audit records. |

### 3.1 Required measurement fixtures

Write these failing tests before implementing each behavior.
Use controlled clocks, saved events, model responses, and usage records.
These fixtures test application contracts. They do not establish live model quality or provider coverage.
The [measurement contract](spec-measurement-contract.md) controls formulas, event meanings, and missing values.

**UT-13: outcome calculations and cohorts.**

- Use G = 12, A = 6, E = 3, and R = 1.
- Expect N = 10 and two pending items.
- Expect approval 60%, edits 30%, rejection 10%, adoption 90%, and review coverage 10/12.
- Check that stored outcome shares sum to one before display rounding.
- For G = 0, expect null rates and Not measured labels.
- For G = 5 and N = 0, expect zero review coverage and five pending items.
- Keep outcome shares null when N = 0.
- Select cohort items by recommendation availability time, including the start and excluding the end.
- Use the latest final review saved by the report cutoff.
- Verify UTC storage, display time zones, filter persistence, and cutoff reproduction.
- Verify metric_definition_version = d24-v1 and saved model, prompt, and source cohort filters.
- Aggregate counts before calculating rates. Do not average percentages from different groups.
- Include valid presented items from partial jobs in G.
- With seven review items across ten selected obligations, expect result coverage of 7/10.
- Include selected obligations from failed and partial runs in that denominator.
- Select run cohorts by job_admitted_at, even when a run produced no recommendation.
- Admit two runs with 20 obligations each. Return 20 review items from one run and fail the other.
- Expect result coverage 20/40. Keep the failed run visible beside the review-item cohort.
- Keep unchecked obligations separate from generated needs_review findings.
- Separate model/prompt versions, statuses, reviewers, and data modes in reports.

**UT-14: review events and revisions.**

- Reject an Edited submission without changed content or a nonblank reason.
- Ignore outer whitespace and line-ending differences when checking changed content.
- Reject a Rejected submission without a nonblank reason.
- Keep comments, evidence requests, and unsaved drafts pending unless a final outcome is explicitly saved.
- Preserve the previous final outcome while a revision remains an unsaved draft.
- Preserve an existing final outcome after a later evidence request.
- Exclude evidence_request events from final-outcome selection, even when their revision is newer.
- Keep acceptance of an existing reviewer revision Edited.
- Count Approved only after explicit acceptance of the original AI item, including after an earlier edit.
- Verify Approved, then Edited, then Rejected at three distinct report cutoffs.
- Preserve all saved events and the original finding, recommendation, and citations.
- Repeat one save request concurrently and after restart.
- Expect one saved logical change for that request and one counted finding_id.
- Save different revisions concurrently against the same expected revision. Accept one and reject the stale write.
- Use server commit time for report cutoffs and increasing per-item revisions to order committed events.
- Give two committed revisions the same timestamp. The larger revision must determine the latest final outcome.
- Retry a delayed duplicate after a newer revision. Return its original event without restoring the older outcome.
- Reject a changed payload under an existing idempotency key. Keep the user's draft on a conflict.
- Create a new run and verify that its findings have no inherited review outcomes.
- Allow every final human outcome for an AI needs_review finding.
- Approval of an evidence request must not change the AI assessment to supported.

**UT-15: retrieval calculations.**

- Use the fixed spans and examples in [the retrieval evaluation plan](eval-model-quality.md#6-separate-retrieval-evaluations).
- Score regulatory passages and bank-evidence passages separately.
- Keep provider source-version counts separate from passage counts.
- Remove duplicate passage identities before scoring.
- Count each required source span once, including across overlapping chunks.
- Score selected context rather than all retrieved candidates.
- Keep unknown relevance labels in the selected-passage denominator and report their count.
- Mark relevance with incomplete labels as a lower bound, not a complete score.
- Count an absent required span as a miss when the result is empty.
- With no required spans, mark recall not applicable and check abstention separately.
- With no selected passages, mark context relevance undefined.
- Preserve wrong-case, wrong-version, and invalid-reference failures independently of text similarity.

**UT-16: traces, time, and limits.**

- Connect each stage and attempt through run_id, job_id, snapshot_id, stage_id, and attempt_id.
- Cover verification, extraction, retrieval, context selection, model calls, validation, persistence, and review events.
- Link a skipped or not_applicable stage to its saved artifact and original processing record.
- Verify monotonic elapsed time during a process and UTC timestamps for correlation.
- Change the test clock during processing and verify that elapsed durations do not become negative.
- Record queue wait separately from worker time and operator review delay.
- Measure review delay from recommendation availability to its first final outcome.
- Later revisions must not change that delay or turn it into measured active review effort.
- Preserve the saved worker deadline after restart and queue redelivery.
- Do not sum overlapping attempts as wall-clock time.
- Count retries, timeouts, uncertain dispatches, and model actions rejected by validation against the persisted allowance.
- Check throttled and provider-rejected dispatched requests, even when provider invocation metrics exclude them.
- Prevent dispatch 25 and preserve completed findings after deadline exhaustion.
- Record first-token time only for streaming model operations.

**UT-17: usage and cost calculations.**

- Preserve missing token counts, provider identifiers, and cost fields as unknown.
- Distinguish numeric model-token counts from prohibited authentication tokens.
- Record cache reads and writes only when the provider supplies them.
- Check retries and applicable cache prices against controlled usage and rate records.
- Preserve currency, rate source/date, model/Region, pricing dimensions, and estimated or billed status.
- Label incomplete cost coverage and distinguish inference from measured system cost.
- Replace a charge estimate with its bill. Count one effective charge and preserve the earlier estimate history.
- Repeat a usage export and verify that it does not add another charge.
- Keep USD and INR amounts in separate totals. Do not present their sum as one currency amount.
- Reject sums that count a system total and its included component charges twice.
- For durations [10, 20, 30, 40], expect nearest-rank p50 = 20 and p95 = 40.
- Show the sample count and descriptive small-sample limitation.
- For an empty sample, expect undefined percentiles.
- With two known failures across four dispatched requests, expect error rate 2/4.
- Count each failed attempt once even when several failure labels apply. Keep model and tool denominators separate.
- Report one unknown outcome separately. Do not count it as a known failure or success.
- With three completed jobs among five admitted jobs, expect completion share 3/5.
- Keep failed and pending jobs in that denominator.
- Use evaluation costs of 4, 3, and 2 currency units for correct, incorrect, and failed cases.
- Expect total measured cost 9 and cost per correct assessment 9/1.
- With no correct cases, expect an undefined cost ratio.
- These fixture amounts do not establish a spending limit or measured product cost.

**UT-18: privacy and audit integrity.**

- Inject fictional private markers into source text, queries, review edits, review reasons, and authentication fields.
- Verify their absence from operational logs, metric payloads, safe errors, and unauthorized progress events.
- Preserve required case evidence in authorized storage within India.
- Reject attempts to include hidden model reasoning in traces.
- Interrupt processing before and after a model dispatch.
- Keep uncertain outcomes explicit and preserve the consumed allowance.
- Require every started attempt to finish or have an unknown or interrupted state.
- Simulate failure when saving audit-critical stage references or finalization data.
- Do not report a completed auditable assessment after that failure.
- Verify that review events cannot modify original findings or source snapshots.

## 4. Contract and integration checks

| Test ID | Requirement | Required result |
|---|---|---|
| CT-01 | REQ-F01, REQ-X06 | Local adapters satisfy shared contracts. Controlled model and regulatory API responses have explicit labels. |
| CT-02 | REQ-X02 | Read/write operations reject another owner's case IDs, source IDs, jobs, findings, and exports, including forged owner fields. |
| CT-03 | REQ-X04 | Duplicate requests/messages and concurrent claims produce one active execution and one finalization. Retry does not reset deadline/counters. |
| CT-04 | REQ-X03, REQ-X04 | A replacement uploaded during processing cannot alter the frozen snapshot. Process restart preserves stage outputs and version references. |
| CT-05 | REQ-F01, REQ-X05, REQ-X06 | API schemas, safe error responses, and exports match the contract. Partial exports stay partial. No external calls occur in default checks. Retrieval exports include verification metadata. |
| CT-06 | REQ-X02, REQ-X05, REQ-X07, REQ-X08 | Aggregates, reports, and exports enforce ownership. Matching filters and cutoffs produce the same counts, outcomes, coverage, and null values. |
| CT-07 | REQ-X03, REQ-X04, REQ-X08 | Stable event identities prevent duplicate trace and metric records after retries or restart. Audit-save failures prevent success. Exporter failures trigger export retries only. |
| CT-08 | REQ-X01, REQ-X02, REQ-X08, REQ-X09 | The baseline pins in.openai.gpt-5.6-luna and its configuration. Every dispatch consumes allowance. No automatic router, global fallback, or autonomous second reviewer runs. |

CT-06 includes cross-owner aggregate filters, direct report URLs, and export requests.
Counts must not reveal another owner's items.
Review history must reproduce an earlier cutoff in the API, browser, Markdown export, and JSON export.
Displayed rounding may differ from stored ratios. Counts and denominators must match.

CT-07 includes duplicate queue messages, worker interruption, exporter timeout, and metric delivery replay.
Retried exports must not trigger another assessment or consume a model call.
Required audit records must remain available when external metric delivery fails.
Both failure types need safe error categories and recoverable saved state.

CT-08 verifies requested model and configuration IDs before dispatch.
Record the actual response model ID when available.
Keep unavailable provider fields unknown.
Test rejected, throttled, timed-out, and uncertain dispatches against the application counter.
AWS invocation totals must not replace this counter.

The regulatory adapter contract must cover these cases:

- Current source responses and valid conditional responses.
- Cached provider content without an authority verification time.
- Missing amendments, withdrawals, or incomplete pagination.
- Changed selected versions before assessment.
- Future-effective amendments and historical assessment dates.
- Timeouts, denied credentials, rate limits, and exhausted retrieval allowances.
- Private query content, arbitrary hosts, private addresses, and unapproved redirects.
- A provider update during an active assessment.
- Restart without repeated source selection or reset retrieval counters.

Reject current-source claims without verification.
Keep active snapshots unchanged.
Never replace private upload limits with unlimited API responses.

A controlled AWS response tests the adapter. It does not prove that AWS accepts the role, request, or region. T8 verifies those conditions.

## 5. Browser checks

| Test ID | Scenario |
|---|---|
| BT-01 | Create/load a case. Refresh regulations. Upload bank files. Inspect extraction. Select obligations. Run an assessment. |
| BT-02 | Open a finding and exact citation. Save each review disposition. Export Markdown and JSON with the original snapshot. |
| BT-03 | Compare explicit regulatory versions, inspect affected controls, and retain the earlier assessment and review history. |
| BT-04 | Exercise empty, uploading, running, denied, partial, failed, invalid-citation, freshness-unverified, changed-selection, and retry states. Preserve entered review notes on failure. |
| BT-05 | Check keyboard focus and navigation, below-768-px layout, text status labels, Synthetic demo badges, and independent Simulated model labels. |
| BT-06 | Save Approved, Edited, and Rejected outcomes. Inspect changed content, reasons, and revision history. Verify counts, coverage, pending items, cohort filters, and empty states. |

BT-06 must preserve a previous final outcome while an unsaved revision exists.
An empty cohort shows Not measured, not perfect acceptance.
A wholly unreviewed cohort shows pending items and zero review coverage.

Show failed jobs, partial jobs, unchecked obligations, and result coverage beside reviewer outcomes.
Keep approval without edits distinct from adoption including edits.
Keep reviewer acceptance distinct from assessment correctness.
Preserve notes and changed content after a failed save.
Keep technical operational logs outside the reviewer interface.

## 6. Live cloud checks — outside the default local suite

| Check ID | What must be observed in AWS |
|---|---|
| CLOUD-01 | Pinned model access, valid SDK/API request, actual inference-profile destinations limited to approved India regions, and a successful synthetic-input invocation |
| CLOUD-02 | Private S3 storage, authorized downloads, real case ownership enforcement, and no private content in frontend assets or operational logs |
| CLOUD-03 | Cognito sign-in and API token validation. Cloud startup/configuration rejects development identity |
| CLOUD-04 | Real SQS/worker/record-store behaviour, including duplicate delivery, persisted allowance, and observable partial/failure outcomes |
| CLOUD-05 | Deployed browser flow, SAM/resource review, spending controls, configuration/retention record, and guided deployment/rollback instructions. Verify real regulatory retrieval, authority synchronization, request privacy, and failure handling. |
| CLOUD-06 | Reconcile real synthetic-run traces with available provider metrics and usage. Verify redaction, India storage, audit recovery, and metric-export recovery. |

CLOUD-06 records model, Region, configuration, time window, and observed measurement coverage.
Compare application dispatches with AWS metrics using their different counting rules.
Account for throttles, rejected requests, retries, unknown outcomes, and reporting delay.
Do not force unequal metric definitions to produce equal totals.

Inspect safe telemetry and authorized audit records after controlled interruptions.
Confirm that external metric delivery retries do not repeat model assessment.
Verify applicable cache measurements and prices only when the selected configuration supplies them.
Unavailable fields remain unknown. An incomplete cost total remains explicitly partial.

Use separate invocation flags or commands for these checks. The default local command must never run them implicitly.

## 7. Acceptance and reporting

Record the run time, source revision or file hashes, environment, command, test IDs, passed/failed/skipped counts, and known limitations.

All required P0 cases must pass. Include skipped and unimplemented cases in the total case count. Do not count them as passes. Identify failures from the application, test harness, or unavailable cloud integration.

Save dated records of failing and passing tests. Exclude private prompt content. Keep logs outside the product UI. Run affected checks after changes. Add other checks when the change or an unresolved concern requires them.

Before delivery, verify the project from a clean source package or checkout. Use the documented dependencies. The recipient must not need ignored local files or an existing developer cache.

[Next: AI evaluation plan](eval-model-quality.md)
