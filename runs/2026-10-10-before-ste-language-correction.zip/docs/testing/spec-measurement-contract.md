# Measurement contract

Date: 2026-10-10.
Decision: [D24](../decisions/gov-decision-log.md#d24---reviewer-outcomes-and-measured-agent-baseline).
Status: Required for development. No application measurements exist yet.

The user selected reviewer outcomes as the north star metric.
The user selected one agent, separate retrieval and assessment evaluations, and a trace for each stage.
The formulas and event rules below define implementation behavior for that direction.
They do not establish a measured baseline or an approved numerical improvement target.

## 1. Product metric and review unit

Use approval without edits as the primary north star rate.
Show edited and rejected shares beside it.
Also show adoption including edits. Keep this secondary measure distinct from approval without edits.
These rates measure reviewer acceptance, not regulatory correctness or operational compliance.

One review item is the immutable finding and its primary recommendation for one selected obligation in one run.
Use finding_id as its stable identity.
The recommendation can propose a correction, request evidence, or state that no correction is needed.
Do not split one recommendation into several items to increase the numerator.
Keep separate supporting observations outside this metric denominator.

A new assessment creates new items and preserves the old items.
Do not carry an earlier review into a new run automatically.

Use these final outcomes:

| Label | Stored value | Meaning |
|---|---|---|
| Approved | approved | The reviewer accepts the original finding and recommendation without changes. |
| Edited | edited | The reviewer saves changed content and accepts that revised finding or recommendation. |
| Rejected | rejected | The reviewer does not accept the original item. A reason is required. |

An edit requires changed review content and a reason.
A comment alone is not an edit.
Ignore outer whitespace and line-ending differences when checking whether content changed.
Require nonblank reasons for edits and rejections.

An unsaved draft is not a final review.
Request more evidence remains a pending review action unless the reviewer explicitly saves a final outcome.
No review is also pending.
A later evidence request does not erase an existing final outcome.
Use event_kind to distinguish final_review from evidence_request.
Only final_review events carry approved, edited, or rejected as a final disposition.

An AI needs_review status can have any final human outcome.
Approval of an evidence request does not mean that the bank satisfies the requirement.
Human outcomes do not overwrite AI findings or their original citations.

Accepting an existing reviewer revision remains Edited.
An Approved outcome must explicitly accept the original AI item, even after an earlier edit.

Choose a cohort by the time when recommendations became available for review.
A cohort is the group of items used in one report.
Record its filters, time zone, start time, exclusive end time, and report cutoff.
Use UTC for stored timestamps. Convert them for display.

At the cutoff, use the latest saved final outcome for each eligible item.
Assign each saved event a server commit timestamp and a strictly increasing revision number within its finding_id.
Order events by committed revision after applying the cutoff to server commit time.
Do not order final outcomes by a client timestamp.

Require the expected current revision when saving a change.
Reject a stale revision and preserve the user's draft for review.
An identical idempotent replay returns the original saved event. A changed payload with the same key is rejected.
Repeated requests and review revisions cannot create additional counted items.

Keep all review events so the report can be reproduced at an earlier cutoff.
Keep a previous final outcome active while a revision remains an unsaved draft.
Record metric_definition_version as d24-v1 with each report.
Record model, prompt, and source cohort filters rather than averaging percentages from different groups.

| Measure | Formula |
|---|---|
| Eligible items, G | All presented review items in the selected cohort, including valid items from partial jobs. |
| Reviewed items, N | A + E + R. |
| Approved items, A | Distinct items whose latest final outcome is approved. |
| Edited items, E | Distinct items whose latest final outcome is edited. |
| Rejected items, R | Distinct items whose latest final outcome is rejected. |
| Approval rate, north star | A / N. |
| Edit rate | E / N. |
| Rejection rate | R / N. |
| Adoption including edits | (A + E) / N. |
| Review coverage | N / G. |
| Pending items | G - N. |

Display rates as percentages with the counts and denominator.
When a denominator is zero, store null and show Not measured.
Never show an empty cohort as 100% approval or 0% rejection.
The three final-outcome shares sum to 100% before display rounding when N is greater than zero.
Report rounding differences without changing stored counts.

Show failed jobs, partial jobs, and unchecked obligations beside review coverage.
Report result coverage as selected obligations with a review item divided by all selected obligations in the run cohort.

Select the run cohort by job_admitted_at, using an inclusive start and exclusive end before the report cutoff.
Count each distinct run_id and obligation_id pair once in the result-coverage denominator.
Select review items by available_at. Select run measures by job_admitted_at.

Label both time bases and windows explicitly. These populations can differ.
Do not derive the run cohort by joining only jobs that produced a recommendation.

Include failed and partial runs in this denominator.
Do not treat unchecked obligations as generated needs_review findings.
These companion measures expose selective output and selective review.

Separate results by model/prompt version, finding status, reviewer, and synthetic versus authorized real data.
Do not pool live results, controlled model simulations, or offline benchmark runs.
Use existing reviewer identity. Do not add reviewer roles or tenant management.

Numerical outcome targets and minimum product-report sample sizes remain TBD after the baseline.
Show small sample counts explicitly. Do not claim statistical significance from them.

## 2. Retrieval evaluations

Evaluate provider source coverage, regulatory passage retrieval, and bank-evidence retrieval separately.
S3 stores bank files. Application code extracts and searches their passages.
The external API must receive no private case content.

Each labelled query must identify its source versions, required source spans, relevant spans, irrelevant examples, and decisive exceptions or conflicts.
Record query identity, retrieval settings, result limit, ranking scores, and context-selection settings.

Label original page, paragraph, or row spans before model execution.
This keeps labels comparable when chunk boundaries change.
Record annotation rules and whether a qualified domain expert reviewed the labels.
Do not use the evaluated model as the only label authority.

Keep development and held-out cases separate.
The existing minimum of 20 held-out assessment cases still applies.
Use their labelled queries where appropriate without claiming that 20 cases prove general coverage.

| Measure | Required definition |
|---|---|
| Provider source coverage | Retrieved required source versions divided by labelled required source versions for the scoped benchmark. Include required amendments and withdrawals. |
| Required-span recall | Distinct required spans covered by selected passages divided by all labelled required spans. Score regulatory and bank sources separately. |
| Context relevance | Relevant selected passages divided by all selected passages under the saved annotation rubric. Record counts and unknown labels. |
| Decisive omissions | Count cases that omit a condition, exception, or conflicting record that can change the result. |
| Retrieval time and volume | Duration, attempts, returned passage count, selected passage count, and selected text size for each query. |

Remove duplicate passage identities before scoring.
An overlapping chunk cannot count the same required span twice.
A missing required span counts as a miss, including when retrieval returns no passages.

When no required spans exist, report recall as not applicable and test correct abstention separately.
An empty result has undefined context relevance. It cannot earn a perfect score.
Report unknown labels separately. Do not silently classify them as relevant.
When relevance labels are incomplete, mark the ratio as a lower bound rather than a complete quality score.

Save per-query counts and aggregate numerator and denominator totals for each source class.
Keep provider-level and passage-level denominators distinct.
Measure context after selection, not only the larger candidate list.
Preserve candidate and selected passage IDs for authorized diagnosis.

Runtime checks verify source status, case scope, snapshot, evidence period, and valid references.
Record provider limitations, source URLs, authority verification time, effective dates, and amendment links.
A fresh response timestamp or high relevance score does not prove complete coverage.

Live requests generally lack complete reference labels. Do not report their recall as measured.
Live source verification remains separate from fixed historical benchmark results.
Block current assessments after failed source verification or changed selected versions under D20.
Keep bounded extra retrieval and needs_review behavior when evidence remains insufficient.

## 3. Assessment quality and audit

For each claim, retain its obligation element, cited passages, evidence period, and concise assessment reason.
Record the exceptions and conflicting evidence considered.
Do not claim that this record proves that no other conflict exists.

Code checks schemas, identities, snapshots, quote matches, access, and limits.
Human evaluation checks contextual support and the conclusion.
An optional model judge can flag cases, but its agreement is not proof.
Do not add an autonomous judge to the baseline.

Retain these approved quality gates:

- At least 90% primary assessment agreement on at least 20 held-out cases.
- All required citations resolve and support their claims in context.
- Zero false supported results on designated critical evidence and adversarial cases.

Keep errors, malformed results, missing results, and unexpected abstentions in the assessment denominator.
Report per-status outcomes and a confusion matrix.
Report unsupported claims, invalid citations, wrong mappings, decisive omissions, incorrect status, and poor remedies separately.

Human approval is product feedback. It does not replace these reference-based quality gates.
Record whether review is by the same operator. Do not claim independent review.

## 4. Runtime traces and cost

Use run_id, job_id, snapshot_id, stage_id, and attempt_id to connect the records.
Stage records cover source verification, extraction, retrieval, context selection, model calls, validation, persistence, and review events.
Use explicit skipped or not_applicable states when a stage uses an existing saved artifact.
Connect that stage to the artifact's original extraction or verification record.

Every started attempt must finish or have an explicit unknown or interrupted status.

Record the baseline model ID and model configuration version for each model attempt.
Also record prompt, schema, extraction, chunking, retrieval, and application versions.
Record the actual response model ID when available.
Do not invent missing provider identifiers or usage fields.

| Runtime measure | Required behavior |
|---|---|
| Duration | Record queue wait, worker elapsed time, each stage, each attempt, and time until the terminal result. |
| Latency summary | Report sample count and p50/p95 for a defined comparable group. Use nearest-rank percentiles. Treat small samples as descriptive. |
| Model use | Record input/output token counts and cache reads/writes when supplied. Record missing values as unknown. |
| First token | Record only for a streaming model operation. Do not invent it for a non-streaming call. |
| Attempts | Record dispatches, retries, throttles, schema failures, rejected actions, timeouts, and uncertain outcomes separately. |
| Tools | Record regulatory and storage/retrieval tool attempts, duration, returned size, errors, and remaining allowance. |
| Job outcomes | Record completed, partial, failed, unchecked obligations, and stop reasons. |
| Cost | Record currency, rate source/date, model/Region, pricing dimensions, and estimated or billed status. Include retries and applicable cache prices. |

Use monotonic elapsed time within a running process and UTC timestamps for correlation.
Report attempt error rate as known failed dispatched attempts divided by all dispatched attempts in the defined cohort.
Count each failed attempt once, even when it has several failure labels.

Group error rates by model or tool operation. Keep their denominators separate.
Report uncertain attempts separately. Do not silently treat them as successful attempts.

Report completed-job share against all admitted jobs in the cohort, including pending, partial, and failed jobs.
Show queued and running counts at the cutoff so incomplete observation time remains visible.
Preserve the saved worker deadline across restarts.
Do not add overlapping attempt durations and call that value wall-clock duration.

Report model/tool stage time separately from queue wait and operator review delay.
Time from recommendation availability to the first final review is review delay, not active reviewer effort.
For nearest-rank p95, sort n durations and select position ceil(0.95 * n), with positions starting at one.
Use the same method with 0.50 for p50.

No p95 target or monetary cost ceiling is invented by this contract.
The 600-second deadline starts at worker start. It is not an end-to-end percentile target.

Sum actual cost records for the declared scope.
Give each logical charge a stable charge ID and compatible measurement scope.
Sum only amounts with the same currency. Otherwise, report separate currency totals.

An authoritative bill replaces its earlier estimate for the same charge. It does not add another charge.
Preserve the estimate history and select one effective amount per charge at the report cutoff.
Deduplicate repeated usage exports before summing costs.
Do not add a total-system amount to the component charges already included in that amount.

Distinguish inference cost from total measured system cost and human review effort.
Report partial cost coverage when tool, infrastructure, or provider usage costs are unavailable.
Unknown costs are not zero. Do not present a partial amount as the complete cost.

Cost per correct assessment uses total measured evaluation cost divided by correct primary cases.
Include spending on failed and incorrect cases in its numerator.
If no correct cases exist, report the ratio as undefined.
Live approval is not a substitute for a correctness label in this metric.

AWS runtime metrics supplement application traces.
They do not replace the saved dispatch counter or the quality records.
The Bedrock Invocations metric excludes throttled and pre-processing rejected requests.
Count every dispatched model request against the existing 24-call allowance, including uncertain attempts.
Numeric token counts are permitted telemetry. Authentication tokens and private text are prohibited in operational logs.

Keep source text, query text, review edits, and review reasons in authorized case evidence storage in India.
Operational logs contain approved identifiers, numeric measurements, and safe error categories only.
Do not retain hidden model reasoning in traces.

Persist audit-critical stage references and finalization data before reporting success.
If that save fails, do not claim a completed auditable assessment.
External metric-export failure must be recorded safely and retried without another model assessment.
Deduplicate metric events by stable event identity during retries and queue redelivery.

## 5. Development and controlled improvement

Write failing tests for formulas, review history, retrieval scoring, traces, privacy, costs, and limits before their application code.
Use controlled clocks, model responses, and usage records in local tests.
These tests prove calculations and contracts, not live retrieval or model quality.
Run separate authorized integration checks and live held-out evaluations.

Start with one agent and the approved model in.openai.gpt-5.6-luna.
Do not introduce automatic routing or an autonomous second reviewer in the baseline.
First measure failure causes and costly stages.

Then test routing or a second reviewer against a named observed failure.
Keep the cases, source versions, tool permissions, and aggregate job limits comparable.
Pin candidate model and router versions. Verify India-only processing and tool compatibility before private use.
Do not tune a candidate from held-out answers and still call those cases untouched.

Preserve prior results, including failures.
Record quality, reviewer outcomes where available, latency, and cost together.
Adopt a candidate only after it passes the existing quality gates and demonstrates the intended benefit.
An experiment does not automatically replace the approved baseline.

## 6. Source references

- [AWS retrieval evaluation metrics](https://docs.aws.amazon.com/bedrock/latest/userguide/knowledge-base-eval-llm-results.html).
- [AWS runtime metrics](https://docs.aws.amazon.com/bedrock/latest/userguide/monitoring-runtime-metrics.html).
- [AWS prompt routing limits](https://docs.aws.amazon.com/bedrock/latest/userguide/prompt-routing.html).
- [Bedrock pricing](https://aws.amazon.com/bedrock/pricing/).

The implementation-specific formulas and review rules above are project definitions.
They do not claim that AWS supplies the product's acceptance measurements.
