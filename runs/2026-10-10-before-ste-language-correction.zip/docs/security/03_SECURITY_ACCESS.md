# Security & Access

> Status: Approved in the planning conversation. First saved on 2026-10-08.
> Required document: [Technical Blueprint](../architecture/02_TECHNICAL_BLUEPRINT.md).
> Decisions: [D05, D09, D10, and D24](../decisions/gov-decision-log.md).

> Verification: These are requirements. No deployed security control has a test result.
> Language revision: 2026-10-10.

The application needs document access for assessments.
A document or model response cannot grant additional access or tool permissions.

## 1. Authentication

Use Cognito authorization-code sign-in with PKCE.
PKCE protects the sign-in code exchange.
Keep access tokens in browser memory.
Disable public sign-up for the demo.

The API must validate authentication.
It must get user identity from the verified token.
It must not trust an owner_id from a request body.

Use an explicit development identity for local operation.
Restrict that identity to local mode and loopback access.
Reject a cloud configuration that enables this bypass.


## 2. Roles and permissions

| Role | Permitted actions | Prohibited actions |
|---|---|---|
| Authenticated operator | Create own cases. Upload authorized files. Run assessments. Inspect sources. Record reviews. Export own reports. | Access another operator's case. Change historical document versions. Add agent tools without approval. |
| Unauthenticated visitor | Load public application assets and the sign-in page. | Read cases, job states, evidence, or reports. |
| Deployment administrator | Configure AWS infrastructure with reviewed permissions. | Bypass normal user ownership rules. Expose private content through public assets. |

The first release permits the same operator to review their own assessment.
Record the human review accurately.
Do not claim independent four-eyes approval.

## 3. Data access and processing regions

| Data | Access rule |
|---|---|
| Cases and bank profiles | Authenticated owner only |
| Original documents and extracted passages | Owner authorization required. Use private storage and an explicit version. |
| Jobs, snapshots, and findings | Use owner-scoped APIs. Restrict the worker to required resources. |
| Review decisions | Authorized case owner only. Append review events. Preserve original findings and recommendations. |
| Review edits and reasons | Store in authorized private case evidence. Exclude from operational logs. |
| Stage traces and metric reports | Check case ownership. Return controlled metadata and authorized artifact references. |
| Exports | Use an authorized snapshot. Keep source and version references. |
| Public frontend assets | CloudFront can serve these assets. Do not include private documents or reports. |

Store private documents, records, and application logs in Mumbai.
The approved model profile can use Mumbai and Hyderabad only.
Verify its actual destinations and permissions before private uploads.

Encrypt data during transfer and storage.
Block public access to the document bucket.
Grant service roles only the required permissions.
Authorize each download through an ownership check.
Use download links with a short validity period.
Do not cache private assessments at a public edge.

Operational logs can contain controlled identifiers, stages, durations, safe error classes, call counts, and numeric model-token counts.
Do not include private text, raw prompts, raw responses, authentication tokens, credentials, or hidden model reasoning.
Keep source text, query text, review edits, and review reasons in authorized case evidence storage in Mumbai.

Treat record identifiers as controlled metadata, not as unrestricted public information.
Keep unknown usage and cost fields unknown.
Do not enable raw model invocation logs by default.
Review service retention terms during T8.

Do not use real bank files as development fixtures or tracked source files.
Explain retention and deletion during deployment.
No automatic deletion schedule has approval.

### External regulatory API

Send only public regulatory identifiers, public topics, and public source URLs.
Do not send bank profiles, private documents, evidence, findings, owner IDs, or private prompts.
Keep the India-only boundary for private content.

Permit only configured HTTPS API endpoints and approved authority domains.
Reject arbitrary hosts, private network addresses, and unapproved redirects.
Do not let document text or the model select new destinations.
Keep provider credentials in server-side secret storage.
Do not expose them in browser assets or logs.

Treat retrieved text as untrusted evidence.
Verify its authority, version metadata, and current-source check.
Reject snippets, incomplete responses, or unknown freshness for a current assessment.
Apply bounded requests, retries, timeouts, pagination, and response sizes.

## 4. Upload and extraction limits

| Item | Approved requirement |
|---|---|
| Formats | English text PDF, DOCX, TXT, and CSV |
| Number | At most 10 documents per case |
| File size | At most 10 MB per file |
| Extracted scope | At most 100 extracted document pages per case |
| Assessment scope | At most 20 explicitly selected obligations |
| Unsupported inputs | Scanned, unreadable, encrypted, oversized, or unsupported files |

Validate file contents as well as extensions.
An upload success does not prove extraction success.
Exclude unvalidated input from retrieval.

Do not silently truncate documents.
Do not imply full coverage when only part of a document is readable.
Explain the rejection or request a smaller supported source.

**T2 implementation detail:** DOCX, TXT, and CSV do not have reliable fixed page counts.
Define an extracted-size equivalent before claiming enforcement of the aggregate page limit.
Keep the approved size limits.
Use paragraph, line, and row references for these formats.
Do not invent PDF page numbers.

## 5. Agent authority and allowances

- Limit reads to the current case and selected snapshot.
- Limit writes to assessment and progress records.
- Do not treat document text as instructions or permissions.
- Do not execute commands or retrieve arbitrary URLs.
- Do not send messages, publish content, or change real bank controls.
- Limit each job to 24 model requests.
- Limit processing to ten minutes from worker start.
- Keep the allowance and deadline through retries and queue redelivery.
- Count malformed responses, rejected actions, and uncertain dispatched calls.
- Show the stop reason and unchecked obligations.
- Do not report an exhausted partial job as completed.

Provider safety functions do not replace application authorization or citation validation.
They do not replace prompt-injection tests.

Start with one bounded agent and the approved pinned model.
Do not enable automatic model routing or an autonomous second reviewer in the baseline.
Use observed failures to define later experiments under the [measurement contract](../testing/spec-measurement-contract.md#5-development-and-controlled-improvement).
Verify candidate destinations, permissions, and tool compatibility before private use.
Experiments retain the aggregate job limits and do not authorize automatic adoption.

## 6. Assessment and review rules

A policy statement is evidence of the stated policy.
It does not establish operational execution.

If required evidence is missing, use needs_review.
Identify the required evidence.
Conflicting relevant evidence prevents a supported finding.

A control gap must identify an evidenced shortfall.
An evidence gap must identify missing information.
Uncertain applicability cannot justify a supported result.

REQ-X07/AC-X07 uses approved, edited, and rejected as final reviewer outcomes.
The [measurement contract](../testing/spec-measurement-contract.md#1-product-metric-and-review-unit) defines their meaning and reporting rules.
Keep one immutable finding and primary recommendation per selected obligation and run.
Only the authenticated case owner can save a human review outcome.
An agent cannot submit that outcome as human approval.

Approved always means acceptance of the original AI item.
Acceptance of an existing edited revision remains edited.
After an edit, approved requires an explicit return to the original item.
Validate accepted content against that original before saving approved.

An edited outcome requires saved changed content and a nonblank reason.
Normalize outer whitespace and line endings before checking whether the content changed.
A rejected outcome requires a nonblank reason.
The request_more_evidence action remains pending unless the reviewer explicitly saves a final outcome.
A comment or unsaved draft cannot count as an edited outcome.

Record reviewer identity, UTC time, event identity, and idempotency key.
Use server commit time and a strictly increasing per-item revision for authoritative event order.
Reject stale writes against an unexpected current revision. Do not trust a client timestamp to order reviews.

Append new review events without changing earlier events or original AI content.
Reject repeated requests that change the payload under the same idempotency key.
Identical retries must have one saved effect.

Use the latest saved final event at the report cutoff for each eligible item.
Keep prior events so earlier reports can be reproduced.
Do not count revisions or retries as additional review items.
A new run requires its own review.
An unsaved revision leaves the previous final outcome active.
A later evidence request does not erase an existing final outcome.

Record metric_definition_version as d24-v1 with each outcome report.
Reviewer acceptance is product feedback, not proof of regulatory correctness or operational execution.
Approval of an evidence request does not establish that the requirement is satisfied.
Keep the same-operator caveat in outcome reports.
A review decision does not authorize changes to bank systems.

REQ-X08/AC-X08 requires per-stage traces with controlled metadata under the [trace contract](../testing/spec-measurement-contract.md#4-runtime-traces-and-cost).
Preserve stage and attempt identity through retries.
Record unknown or interrupted outcomes instead of inventing success.
Do not declare completion before required audit references and finalization data are saved.

REQ-X09/AC-X09 separates retrieval evaluations from assessment evaluations.
Use labelled public or fictional sources in development fixtures.
Do not use the evaluated model as the only authority for expected labels.
Valid references and fresh timestamps do not prove complete retrieval.
Human approval does not replace the existing reference-based quality gates.

## 7. Failures

| Failure | User information | Saved information |
|---|---|---|
| Invalid or unsupported file | File-specific reason and a supported next action | Error class, source ID, and validation stage |
| Missing or conflicting evidence | Needs review. Identify the affected evidence. | Finding status, evidence condition, and valid source references |
| Malformed AI output or false citation | A limited retry. Then a visible failure or partial result. | Validation failure and remaining allowance. No raw private output. |
| Regulatory retrieval unavailable or outdated | Block a current assessment. Show the last successful check. | Source identity, verification state, and safe failure reason |
| Model or service unavailable | Keep inputs. Offer a retry when the allowance permits it. | Failed stage, attempt ID, and consumed allowance |
| Storage unavailable | No success claim. Keep safe form input where possible. | Safe error class and correlation ID |
| Audit-critical save unavailable | Do not report a completed auditable assessment. Preserve recoverable progress. | Safe failure, stage references, and finalization state |
| Review save unavailable | The new outcome is not saved. Preserve the previous final outcome. | Safe failure and review request identity |
| External metric export unavailable | Retry the export without repeating the assessment. | Stable metric-event identity and safe export failure |
| Rate limit | Wait or retry information. No false progress. | Retry data and remaining deadline |
| Duplicate message | Existing progress or result. No second assessment. | Execution claim and finalization result |
| Unauthorized request | Access denied. No case-content disclosure. | Minimal access-denial event |
| Exhausted allowance | Partial or failed status. Show unchecked work. | Saved counter, deadline, and completed stage outputs |

Do not display raw stack traces.
Keep safe user input where possible.
State the next action.

## 8. Required negative tests

The local test plan covers these cases:

- Requests for another case's objects.
- Altered owner fields.
- Invalid tokens.
- A cloud configuration with development identity.
- Source instructions that request prohibited actions.
- Invented citations.
- Missing or stale evidence.
- Repeated delivery.
- Exhausted allowances.
- Malformed files.
- Forged review identity or access to another case's trace.
- An edited outcome without changed content or a reason.
- A rejected outcome without a reason.
- Repeated review requests or conflicting idempotency payloads.
- Private text or authentication tokens in operational telemetry.
- Audit-save failures that could incorrectly produce completed status.

The [local test plan](../testing/spec-local-test-plan.md) assigns tests for review outcomes, trace privacy, and audit failures.
The [measurement contract](../testing/spec-measurement-contract.md) controls their required behavior.

Live checks must verify IAM permissions, storage privacy, Cognito, inference destinations, and service connections.
Verify the regulatory provider's authority coverage and request privacy separately.
Verify trace and review-data privacy in the actual cloud configuration.
Local substitutes cannot prove that these cloud controls work.

[Next: Frontend specification](../frontend/04_FRONTEND_SPEC.md)
