# Frontend Spec - reviewer interface

> Status: Approved in the planning conversation. First saved on 2026-10-08.
> Required documents: [PRD](../product/01_PRD.md) and [Security & Access](../security/03_SECURITY_ACCESS.md).

> Reference screenshots: **NONE — design risk**. The user approved the default design.
> Decision: [D11](../decisions/gov-decision-log.md).
> Language revision: 2026-10-09.

> Measurement update: 2026-10-10. Follow [D24](../decisions/gov-decision-log.md#d24---reviewer-outcomes-and-measured-agent-baseline) and the [measurement contract](../testing/spec-measurement-contract.md).

The interface must show the requirement, control, evidence, finding, and proposed correction.
The reviewer must be able to inspect and challenge each finding.

## 1. Screens and functions

### Cases

Show the bank profile, assessment status, and latest activity.
Give fictional cases a visible Synthetic demo label.
Provide a create-case action and a load-demo action.

Explain the contents of a case in the empty state.
Do not show invented completed assessments.

### Case workspace

Use Documents, Assessment, and Regulatory Changes tabs.

| Tab | Required functions |
|---|---|
| Documents | Upload bank files. Select their role. Refresh public regulations through the API. Show extraction, source versions, and verification times. Explain formats and limits before upload. |
| Assessment | Select up to 20 obligations. Start a job. Show progress. Open findings. |
| Regulatory Changes | Select explicit older and newer versions. Show changes and affected controls. Keep access to the previous assessment. |

If the selection exceeds a limit, request a smaller scope.
Do not select an arbitrary subset without telling the user.

Show the regulatory source authority, publication date, effective date, and last successful authority check.
Label failed checks Freshness unverified.
Do not permit a new current assessment after a failed check.
If a selected version changed, request selection review.
Keep earlier reports accessible with their original versions and dates.

### Finding detail

Show **requirement → mapped control → evidence → finding → proposed fix**.

Open the exact source passage beside the finding.
Include the document, version, and page, paragraph, line, or row location.

Reference resolution alone does not establish support.
The preview must permit review of the passage's meaning.
Keep review controls near the finding.

## 2. Human review and agent events

Provide Approve, Edit and accept, Reject, and Request more evidence actions.
Show final outcomes as Approved, Edited, and Rejected.
Keep the original AI finding and recommendation visible beside any saved reviewer revision.
Require changed review content and a reason for Edit and accept.
Require a reason for Reject.

A comment alone does not change an Approved item into an Edited item.
Request more evidence is a pending action until the reviewer saves a final outcome.
Keep unsaved drafts separate from saved review events.
Do not discard a saved final outcome while the reviewer edits an unsaved revision.

Show review history and the current saved outcome.
Accepting a saved reviewer revision keeps the Edited outcome.
An Approved outcome must explicitly accept the original AI item, including after an earlier edit.
Retry a failed save without duplicate events or metric counts.

If another save changed the current revision, show a conflict and keep the draft.
Require review of the saved content before resubmitting the changed draft.
Do not carry a review outcome into a new assessment automatically.

An Approved outcome accepts the recommendation. It does not change the original AI finding status.
For example, the reviewer can approve a needs_review finding that requests missing evidence.
Do not display that approval as Supported or as proof of bank compliance.

Show completed stages, tool actions, inspected sources, and stop reasons.
Use factual events such as “Retrieved three evidence passages.”
Do not show hidden chain-of-thought.
Do not invent progress percentages.

Label controlled model outputs Simulated.
Live outputs must identify their input snapshot and job status.
A realistic demo dataset must not hide simulated model processing.

### Review outcome summary

Show the summary in the Assessment tab for the selected authorized cohort.
Use approval without edits as the main rate.
Show the edited and rejected shares with their counts and common reviewed-item denominator.
Show adoption including edits as a separate secondary measure.
Also show review coverage, pending items, result coverage, failed jobs, partial jobs, and unchecked obligations.

Display the recommendation-availability window, filters, and report cutoff for reviewer rates.
Display the job-admission window for runtime and result-coverage measures.
These time bases can produce different populations. Label them separately.
Use Not measured for zero denominators. Never invent an empty-cohort percentage.

Use the latest saved final review for each item. Revisions must not increase the item count.
Show the baseline model/prompt version and synthetic or live status for comparisons.
Keep simulated and live results separate.
Do not label approval as accuracy.

Keep the same formulas in the interface, API response, and export.

### Runtime details

Show actual stage outcomes, duration, retry counts, and safe stop reasons in job details.
Provide authorized links from a trace to its selected source passages.
Show numeric model token usage when available.
Label cost as estimated or billed and state its included components.

Show Unknown when usage or price data is absent.
Do not show a partial cost estimate as total system cost.
Keep raw prompts, responses, query text, credentials, and hidden reasoning out of the event timeline.
Allow source text and reviewer content only in their authorized evidence and review views.

An audit-save failure cannot appear as a completed assessment.
An external metric-export failure must not trigger another assessment.

**Technical:** The timeline shows application audit events.
**ELI10:** It shows the agent's actions and the documents used for those actions.

## 3. Visual specification

| Role | Value | Use |
|---|---|---|
| Page background | #F8FAFC | Workspace background |
| Surface | #FFFFFF | Panels, tables, and source previews |
| Text | #0F172A | Main text and headings |
| Primary/action | #1D4ED8 | Buttons, links, and active controls |
| Muted text | #475569 | Secondary data. Verify contrast. |
| Supported indicator | #166534 | Status text and icon. Do not use color alone. |
| Review/partial indicator | #92400E | Needs-review and partial states |
| Gap/error indicator | #B91C1C | Evidenced gaps and failures |

The last four text and status colors are implementation defaults.
They extend the approved palette.
Verify contrast in the actual interface.

Use local system fonts.
Use 16 px body text and approximately 14 px labels.
Use heading sizes from 20–28 px.
Use 8 px spacing increments and 8 px corners.
Use light borders and limited shadows.

Use action labels such as Run assessment, Compare versions, Inspect source, and Save review.
Associate each input with its label.
Put validation information beside the related field.

## 4. Layout and access

Design the desktop workspace first.
Show the finding and source panel beside each other.

Below 768 px, replace wide tables with stacked cards.
Use a full-width evidence view.

Keyboard navigation must reach tabs, findings, source previews, and review controls.
Keep keyboard focus visible.
Move focus predictably when the source panel opens.
Restore focus when the panel closes.

Include text in status labels.
Distinguish Needs review from a passed assessment.

## 5. Connections and interface states

| Connection | Progress state | Failure or partial state |
|---|---|---|
| Identity | Sign-in indicator | Return to sign-in. Keep safe navigation context. |
| Cases | Load indicator | Retry action. No false case data. |
| Upload/extraction | Per-file stages | Specific rejection. Show that the file is not ready. |
| Regulatory retrieval | Source-check progress and selected scope | Freshness unverified. Retry action. No silent use of an old source. |
| Assessment job | Actual stage and tool events | Stop reason, completed findings, and unchecked obligations |
| Citations | Source-load indicator | Unavailable or invalid reference. No invented excerpt. |
| Version comparison | Identified version pair and progress | Keep the previous assessment and valid comparison outputs. |
| Review save | Pending-save indicator | Keep the note. Retry without duplicate decisions. |
| Export | Generation indicator | Explain failure. Do not label a partial export successful. |

Export only an authorized snapshot.
Include source references, versions, findings, job status, limitations, and reviewer decisions in Markdown and JSON exports.
Label partial exports explicitly.
Include regulatory source URLs, authority verification time, and freshness status.

Include original recommendation IDs, saved reviewer revisions, outcome counts, denominators, cohort definition, and report cutoff.
Include metric version and available safe runtime measurements with their missing-data labels.
An export with an earlier cutoff must preserve the review outcomes that were effective at that cutoff.

## 6. Browser acceptance

Use this sequence:

1. Refresh regulations and upload bank documents.
2. Start an assessment.
3. Inspect a citation.
4. Record a review.
5. Compare regulatory versions.
6. Export the result.

Also do tests of invalid uploads, access denial, interrupted jobs, invalid citations, keyboard navigation, and a narrow viewport.
BT-06 must also test all three final review outcomes, pending actions, edit validation, outcome revisions, zero denominators, and summary/export parity.
These are planned acceptance checks.
The project has no tested browser implementation.

[Next: Feature tickets](../delivery/05_FEATURE_TICKETS.md)
